#include <iostream>
using namespace std;
struct Posicion
{
    int fila;
    int columna;
    int valor;
};
Posicion* matriz;
Posicion* construirMatrizIdentidad(int n)
{
    Posicion* pPos = new Posicion();
    pPos->columna = 0;
    pPos->fila = 0;
    pPos->valor = 0;
    while((pPos->columna != n) && (pPos->fila != n))
    {
        if(pPos->columna == pPos->fila)
        {
            pPos->valor = 1;
            if(pPos->columna == n)
            {
                pPos->fila += 1;
                pPos->columna = 0;
            }
            else
            {
                pPos->columna += 1;
            }
        }
        else
        {
            pPos->valor = 0;
            if(pPos->columna == n)
            {
                pPos->fila += 1;
                pPos->columna = 0;
            }
            else
            {
                pPos->columna += 1;
            }
        }
        matriz = pPos;
    }
    return matriz;
}
int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
