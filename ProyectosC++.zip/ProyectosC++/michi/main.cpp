#include <iostream>
using namespace std;
enum Simbolo
{
    Nada, Cruz, Circulo
};
struct Casilla
{
    Simbolo simbolo;
    Casilla* casillaDerecha;
    Casilla* casillaInferior;
};
Casilla* armarFila(int tam)
{
    Casilla* pPrimeraCasilla = NULL;
    Casilla* pCasillaSiguiente = NULL;
    for(int i = 0; i < tam; i++)
    {
        Casilla* pCasilla = new Casilla();
        pCasilla->casillaDerecha=NULL;
        pCasilla->casillaInferior=NULL;
        pCasilla->simbolo=Nada;
        if(pCasillaSiguiente != NULL)
        {
            pCasillaSiguiente->casillaDerecha = pCasilla;
        }else
        {
            pPrimeraCasilla = pCasilla;
        }
        pCasillaSiguiente = pCasilla;
    }
    return pPrimeraCasilla;
}
Casilla* armarTablero(int tam)
{
    Casilla* pFilaAnterior = NULL;
    Casilla* pPrimeraCasillaFila = NULL;
    for(int i = 0; i<tam; i++)
    {
        Casilla* pFila = armarFila(tam);

        if(pFilaAnterior != NULL)
        {
            pFilaAnterior->casillaInferior = pFila;
        }else
        {
            pPrimeraCasillaFila = pFila;
        }
        pFilaAnterior = pFila;
    }
    return pPrimeraCasillaFila;
}
void colocarSimbolo(Casilla* tablero, int posFila, int posCol, Simbolo simbolo)
{
    Casilla* pCasilla = NULL;
    Casilla* pTabla = tablero;
    int fil=0, col=0;
    while(pTabla != NULL)
    {
        pCasilla = pTabla;
        if(fil == posFila)
        {
            while(pCasilla != NULL)
            {
                if(col == posCol)
                {
                    pCasilla->simbolo = simbolo;
                    break;
                }else
                {
                    pCasilla = pCasilla->casillaDerecha;
                }
                col++;
            }
        }else
        {
            pTabla = pTabla->casillaInferior;
        }
        fil++;
    }
}
Casilla* obtenerCasilla(Casilla* tablero, int fila, int columna)
{
    Casilla* pTabla = tablero;
    Casilla* pCasilla = NULL;
    int fil = 0, col = 0;
    while(pTabla != NULL)
    {
        pCasilla = pTabla;
        if(fil == fila)
        {
            while(pCasilla != NULL)
            {
                if(col == columna)
                {
                    return pCasilla;
                }else
                {
                    pCasilla = pCasilla->casillaDerecha;
                    col++;
                }
            }
        }else
        {
            pTabla = pTabla->casillaInferior;
            fil++;
        }
    }
}
bool IgualdadFila(Casilla* tablero, Simbolo simbolo, int tam, int f)
{
    int c=0;
    for(int i = 0; i < tam; i++)
    {
        if(obtenerCasilla(tablero,f,i)->simbolo == simbolo)
        {
            c++;
        }
    }
    if(c==3)
    {
        return true;
    }
    return false;
}
bool IgualdadColumna(Casilla* tablero, Simbolo simbolo, int tam, int c)
{
    int b=0;
    for(int i = 0; i < tam; i++)
    {
        if(obtenerCasilla(tablero,i,c)->simbolo == simbolo)
        {
            b++;
        }
    }
    if(b==3)
    {
        return true;
    }
    return false;
}
bool IgualdadDiagonal(Casilla* tablero, Simbolo simbolo, int tam)
{
    int j = tam-1;
    int c=0;
    int a=0;
    for(int i = 0; i < tam; i++)
    {
        if(obtenerCasilla(tablero,i,i)->simbolo == simbolo)
        {
            c++;
        }
        if(obtenerCasilla(tablero,i,j)->simbolo == simbolo)
        {
            j--;
            a++;
        }
    }
    if((a==3) || (c==3))
    {
        return true;
    }
    return false;
}
bool obtenerGanador(Casilla* tablero, int tam, Simbolo simbolo)
{
    for(int i = 0; i < tam; i++)
    {
        if(IgualdadColumna(tablero,simbolo,tam,i) || IgualdadFila(tablero,simbolo,tam,i) || IgualdadDiagonal(tablero,simbolo, tam))
        {
            return true;
        }
    }
    return false;
}
void pintar(Casilla* tablero)
{
    Casilla* pCasilla = NULL;
    Casilla* pFila = tablero;
    while(pFila != NULL)
    {
        pCasilla = pFila;
        while(pCasilla != NULL)
        {
            switch(pCasilla->simbolo)
            {
            case Nada:
                cout << " * " << "\t";
                break;
            case Cruz:
                cout << " X " << "\t";
                break;
            case Circulo:
                cout << " O " << "\t";
                break;
            }
            pCasilla = pCasilla->casillaDerecha;
        }
        cout << endl;
        cout << endl;
        pFila = pFila->casillaInferior;
    }
}

int main()
{
    Casilla* tablero = armarTablero(3);
    colocarSimbolo(tablero, 0, 2, Cruz);
    colocarSimbolo(tablero, 2, 1, Cruz);
    colocarSimbolo(tablero, 2, 0, Cruz);
    pintar(tablero);
    if(obtenerGanador(tablero,3,Cruz))
    {
        cout << "gana cruz" << endl;
    }else
    {
        cout << "no gana cruz" << endl;
    }
    return 0;
}
