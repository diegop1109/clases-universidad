#include <iostream>

using namespace std;

int main()
{
    int numeros[3];

    *numeros = 1;
    *(numeros+1)=3;
    *(numeros+2)=5;
    cout << numeros[0] << endl; // devuelve el valor
    cout << (*numeros) << endl; // devuelve el valor
    cout << &(*numeros) << endl; // "&" devuelve la posicion en memoria de un valor
    for(int i=0; i<3; i++)
    {
        cout << *(numeros+i) << endl;
    }
    return 0;
}
