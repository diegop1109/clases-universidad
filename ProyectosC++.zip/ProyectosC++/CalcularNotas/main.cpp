#include <iostream>
using namespace std;
#include<string>
enum Tipo
{
    TA, EP, EF
};
struct Nota
{
    int valor;
    Tipo tipo;
    Nota* siguienteNota;
};
struct Alumno
{
    string codigo;
    string carrera;
    Alumno* siguienteAlumno;
    Nota* notas;
};
struct Seccion
{
    int numero;
    string curso;
    Alumno* alumnos;
};
Seccion seccion602;
void registrar_alumno(string codigo, string carrera)
{
    Alumno* al1=new Alumno();   //asigmacion dinamica de alumno, utilizando un espacio extra en la memoria
    al1->codigo=codigo;
    al1->carrera=carrera;
    al1->siguienteAlumno=NULL;
    al1->notas=NULL;
    if(seccion602.alumnos==NULL) //si no hay ningun alumnno
    {
        seccion602.alumnos=al1; //le asignamos al1
    }else //si ya hay alumnos registrados
    {
        Alumno* pAlumno=NULL;
        pAlumno=seccion602.alumnos;
        while(pAlumno->siguienteAlumno!=NULL) //para recorrer la lista enlazada
        {                                      //reccorre el while hasta que encuentre que no existe un "siguiente alumno"
            pAlumno=pAlumno->siguienteAlumno; //si el "siguiente alumno" no es nulo, sigue recooriendo hasta que
        }                                           //"siguiente alumno" sea nulo para poder reemplazzarlo fuera del while
        pAlumno->siguienteAlumno=al1; //una vez el "siguiente alumno" no existe. el "siguietne alumno" sera "al1"(nueva enrada)
    }
}
void registrar_nota(string codigo, int nota, Tipo tipoNota)
{
    Alumno* pAlumno=NULL;
    pAlumno=seccion602.alumnos; //obtenemos la referencia al primer alumno de la lista
    while(pAlumno!=NULL)    //iterar sobre la lista de alumnos (registrados)
    {
        if(pAlumno->codigo==codigo) //comparamos entre codigos hasta encontrar al alumno
        {
            //agregar nueva nota
            Nota* pNota=pAlumno->notas; //un puntero hacia las notas de ESE alumno
            //asignacion dinamica
            Nota* nuevaNota=new Nota();     //un puntero con los registros de aquella nota
            nuevaNota->valor=nota;          //asignamos la nota
            nuevaNota->tipo=tipoNota;       //asignamos el TIPO de nota (final, parcial o tarea)
            nuevaNota->siguienteNota=NULL;   //siguiente nota apuntara a nulo

            if(pNota==NULL)          //si el alumno no tiene notas registradas
            {
                pAlumno->notas = nuevaNota;        //directamente asignamos la nota al alumno
            }else    //si al alumno ya se la han asignado notas anteriormente
            {
                while(pNota->siguienteNota!=NULL)  //recorrer MIENTRAS "siguiente nota" tenga registro
                {
                    pNota=pNota->siguienteNota;      // actualizamos para poder encontrar que no hay registro en "siguiente nota"
                }
                //una vez encontrada la "siguiente nota" que no tiene registro (==NULL)
                pNota->siguienteNota=nuevaNota;       // asignamos "nueva nota" a la "siguiente nota"
            }
            break; //terminamos el bucle
        }
        else  //si el alumno al que apuntamos no tiene coincidencia en "codigo", actualizamos el puntero al siguiente
        {                                                                                           //y volvemos a iterar
            pAlumno=pAlumno->siguienteAlumno;
        }
    }
}
int obtenerCantidadAlumnos()
{
    if(seccion602.alumnos==NULL) //si no hay alumnos registrados
    {
        return 0;               //devolver "0"
    }else                           //si existen alumnos registrados
    {
        Alumno* pAlumno=seccion602.alumnos; //puntero hacia el primer alumno registrado
        int c=0;
        while(pAlumno!=NULL)            //hasta que ya no hayan alumnos, seguimos recorriendo
        {
            c++;                //aumenta el contador
            pAlumno=(*pAlumno).siguienteAlumno;     //se actualiza el puntero hacia el siguiente alumno
        } return c; //una vez terminado el bucle, devolvemos el contador
    }
}
/*double calcular_promedio()
{
     Alumno* pAlumnos = seccion602.alumnos;
    double* promedios= new double[obtenerCantidadAlumnos()];
    int cont = 0;
    //promedio de cada alumno
    while (pAlumnos != NULL) {
        Nota* naux = pAlumnos->notas;
        double suma = 0.0;


        while(naux!=NULL){
            cout << 1 << endl;
            if (naux->tipo == EP || naux->tipo == TA) {
                suma += (naux->valor) * 3;
            }
            else {
                suma += (naux->valor) * 4;
            }
            cout << "suma: " << suma << endl;
            naux = naux->siguienteNota;
        }

        promedios[cont] = suma / 10.0;
        cout <<pAlumnos->codigo<<": "<< promedios[cont]<<endl<<endl;
        pAlumnos = pAlumnos->siguienteAlumno;
        cont++;
    }
}*/
float calcularPromedioAlumno(Alumno* pAlumno)       //calcular individualmente el promedio de cada alumno
{
    Nota* pNota = pAlumno->notas;       //puntero a las notas de ESE alumno
    float acum = 0.0;
    while(pNota!=NULL)      //mientras aun tenga notas
    {
        switch(pNota->tipo)     //escoger entre los TIPOS de nota disponibles (TA, EP ,EF)
        {
            case TA:
                acum = acum + (3*pNota->valor); //TA y EP se calculan de forma similar
                break;
            case EP:
                acum += (3*pNota->valor);
                break;
            case EF:
                acum += (4*pNota->valor);       //EF se calcula de forma distinta a TA y EP
                break;
        }
        pNota = pNota->siguienteNota;       //pasamos a la "siguiente nota"
    }
    float promedioTotal = acum/10;      //calcular el promedio con formula
    return promedioTotal;       //devolver resultado
}
float calcular_promedio()
{
    Alumno* pAlumno=seccion602.alumnos; //puntero al primer alumno
    float promedioTotal=0.0;
    int contador=0;
    while(pAlumno!=NULL)        //mientras aun hayan alumnos
    {
        float sum = calcularPromedioAlumno(pAlumno);   //nueva variable para calcular promedio de ESE alumno
        promedioTotal = promedioTotal + sum;       //sumatoria de todos los promedios individuales
        contador++;                             //contador para la cantidad de alumnos en la seccion
        pAlumno = pAlumno->siguienteAlumno;     //pasamos al "siguiente alumno"
    }
    float promedio = promedioTotal/contador;    //calculamos el promedio de la seccion dividiendo la sumatoria/total alumnos
    return promedio;
}

void imprimirNotasAlumno(Alumno* pAlumno)
{
    Nota* pNota = pAlumno->notas;
    cout << "codigo: " << pAlumno->codigo << "\t\t";
    while(pNota != NULL)
    {
        switch (pNota->tipo)
        {
        case TA:
            cout << "TA:" << pNota->valor << "\t";
            break;
        case EP:
            cout << "EP:" << pNota->valor << "\t";
            break;
        case EF:
            cout << "EF:" << pNota->valor << "\t";
            break;
        default:
            break;
        }
        pNota = pNota->siguienteNota;
    }
    cout << endl;
}
void imprimirSeccion()
{
    Alumno* pAlumno = seccion602.alumnos;
    while (pAlumno != NULL)
    {
        imprimirNotasAlumno(pAlumno);
        pAlumno = pAlumno->siguienteAlumno;
    }
}
int main()
{
    //se define la seccion
    seccion602.numero=602;
    seccion602.curso="Lenguajes de Programacion";
    seccion602.alumnos= NULL;

    registrar_alumno("20151144", "ingenieria de sistemas");
    registrar_alumno("20133144", "ingenieria de sistemas");
    registrar_alumno("20171160", "ingenieria de sistemas");
    cout << "ahora los promedios" << endl;
    registrar_nota("20151144", 13, TA);
    registrar_nota("20151144", 13, EF);
    registrar_nota("20151144", 13, EP);

    registrar_nota("20133144", 15, TA);
    registrar_nota("20133144", 15, EF);
    registrar_nota("20133144", 14, EP);

    registrar_nota("20171160", 15, TA);
    registrar_nota("20171160", 12, EF);
    registrar_nota("20171160", 13, EP);

    imprimirSeccion();
    cout << "promedio de la seccion: " << calcular_promedio << endl;
    return 0;
}
