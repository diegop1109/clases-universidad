#include <iostream>
using namespace std;
struct Fajo
{
    string valor;
    int cantidad;
    Fajo* siguienteFajo;
};
Fajo* generarFajos()
{
    Fajo* fajo4 = new Fajo();
    fajo4->valor = "20";
    fajo4->cantidad = 6;
    fajo4->siguienteFajo = NULL;

    Fajo* fajo3 = new Fajo();
    fajo3->valor = "50";
    fajo3->cantidad = 3;
    fajo3->siguienteFajo = fajo4;

    Fajo* fajo2 = new Fajo();
    fajo2->valor = "20";
    fajo2->cantidad = 5;
    fajo2->siguienteFajo = fajo3;

    Fajo* fajo1 = new Fajo();
    fajo1->valor = "10";
    fajo1->cantidad = 20;
    fajo1->siguienteFajo = fajo2;

    return fajo1;
}
int contarMonto(Fajo* pFajo)
{
    int valor = 0;
    if(pFajo->valor == "10")
    {
        valor = 10;
    }
    if(pFajo->valor == "20")
    {
        valor = 20;
    }
    if(pFajo->valor == "50")
    {
        valor = 50;
    }
    return valor * pFajo->cantidad;
}
int calcularTotalDinero(Fajo* pFajo)
{
    int total = 0;
    while(pFajo != NULL)
    {
        total += contarMonto(pFajo);
        pFajo = pFajo->siguienteFajo;
    }
    return total;
}
void imprimirTotalesPorFajo(Fajo* pFajo) //esta funcion es un error mio, calcula los totales por fajos, pero pedian total por "valor"
{
    int total = 0, a = 0;
    while(pFajo != NULL)
    {
        int c = 0;
        a++;
        c += contarMonto(pFajo);
        total += contarMonto(pFajo);
        cout << "monto fajo " << a << " :" << c << endl;
        pFajo = pFajo->siguienteFajo;
    }
    cout << "total: " << total << endl;
}
void imprimirTotalPorValor(Fajo* pFajo)
{
    int total = 0;
    int c10 = 0, c20 = 0, c50 = 0;
    while(pFajo != NULL)
    {
        if(pFajo->valor == "10")
        {
            c10 += contarMonto(pFajo);
        }
        if(pFajo->valor == "20")
        {
            c20 += contarMonto(pFajo);
        }
        if(pFajo->valor == "50")
        {
            c50 += contarMonto(pFajo);
        }
        total += contarMonto(pFajo);
        pFajo = pFajo->siguienteFajo;
    }
    cout << "valor 10: " << c10 << endl;
    cout << "valor 20: " << c20 << endl;
    cout << "valor 50: " << c50 << endl;
    cout << "total: " << total << endl;
}
string obtenerMayorCantidadValor(Fajo* pFajo)
{
    string val;
    int cant = 0;
    while(pFajo != NULL)
    {
        if(pFajo->cantidad > cant)
        {
            cant = pFajo->cantidad;
            val = pFajo->valor;
        }
        pFajo = pFajo->siguienteFajo;
    }
    cout << "mayor cantidad segun valor: " << val << endl;
}
int main()
{
    Fajo* primero = generarFajos();
    cout << "monto total en caja: " << calcularTotalDinero(primero) << endl;
    imprimirTotalPorValor(primero);
    obtenerMayorCantidadValor(primero);
    return 0;
}
