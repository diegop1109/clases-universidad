#include <iostream>
#include<string>
using namespace std;
struct Videojuego
{
    string nombre;
    int precio;
    Videojuego* siguienteVideojuego;
};
Videojuego listaVideojuegos;
void agregarVideojuego(string nombre, int precio) //funcion para agregar nuevos juegos a la lista
{
    // asignacion dinamica
    Videojuego* nuevoJuego = new Videojuego();
    //asignar parametros
    nuevoJuego->nombre = nombre;
    nuevoJuego->precio = precio;
    nuevoJuego->siguienteVideojuego = NULL;
    if(listaVideojuegos == NULL) //si no existen videojuegos en la lista
    {
        listaVideojuegos = nuevoJuego; //agregar directamente
    }else
    {
        Videojuego* pJuego = NULL;
        pJuego = listaVideojuegos;
        while(pJuego->siguienteVideojuego != NULL)
        {
            if()
            pJuego = pJuego->siguienteVideojuego;
        }
        pJuego->siguienteVideojuego = nuevoJuego;
    }
}
int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
