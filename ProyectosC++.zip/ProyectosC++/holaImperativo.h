#ifndef HOLAIMPERATIVO_H
#define HOLAIMPERATIVO_H


class holaImperativo
{
    public:
        holaImperativo();
        virtual ~holaImperativo();

    protected:

    private:
};

#endif // HOLAIMPERATIVO_H
