#include<string>
#include<iostream>

using namespace std;

enum Tipo
{
    TA, EP, EF
};

struct Nota
{
    int valor;
    Tipo tipo;
    Nota* siguienteNota;
};

struct Alumno
{
    string codigo;
    string carrera;
    Alumno* siguienteAlumno;
    Nota* notas;
};

struct Seccion
{
    int numero;
    string curso;
    Alumno* alumnos;

};
Seccion seccion602;

void registrar_alumno(string codigo, string carrera)
{
    Alumno* al1 = new Alumno();
    al1->codigo = codigo;
    al1->carrera = carrera;
    al1->siguienteAlumno = NULL;
    al1->notas = NULL;

    if (seccion602.alumnos == NULL)
    {
        // Asignacion directa de un allumno
        seccion602.alumnos = al1;
    }else
    {
        Alumno* pAlumno = NULL;

        pAlumno = seccion602.alumnos;

        // Recorremos la lista enlazada
        while( pAlumno->siguienteAlumno != NULL)
        {
            pAlumno = pAlumno->siguienteAlumno;
        }

        pAlumno->siguienteAlumno = al1;

    }
}

void registrar_nota(string codigo, int nota, Tipo tipoNota)
{
    Alumno* pAlumno = NULL;

    // Obtenemos referencia al primera alumno de la lista
    pAlumno = seccion602.alumnos;

    // Iteramos sobre los alumnos
    while (pAlumno != NULL)
    {
        // Comparo si es el alumno que busco
        if (pAlumno->codigo == codigo)
        {
            // Agregar una nueva nota
            Nota* pNota = pAlumno->notas;

            // Creo la nota utilizando asignacion dinamica
            Nota* nuevaNota = new Nota();
            nuevaNota->valor = nota;
            nuevaNota->tipo = tipoNota;
            nuevaNota->siguienteNota = NULL;

            // La nota creada tengo que agregarla a la lista
            // Si no hay notas?
            if (pNota == NULL)
            {
                pAlumno->notas = nuevaNota;
            }else
            {
                // Recorremos notas
                while(pNota->siguienteNota != NULL)
                {
                    pNota = pNota->siguienteNota;
                }
                pNota->siguienteNota = nuevaNota;
            }
            break;
        }else
        {
            // Actualizamos pAlumno para que apunte al siguiente
            pAlumno = pAlumno->siguienteAlumno;
        }
    }
}

float calcularPromedioAlumno(Alumno* pAlumno)
{
    Nota* pNota = pAlumno->notas;

    float acum = 0.0;
    while(pNota != NULL)
    {
        switch (pNota->tipo)
        {
        case TA:
            acum = acum + (3 * pNota->valor);
            break;
        case EP:
            acum += (3 * pNota->valor);
            break;
        case EF:
            acum += (4 * pNota->valor);
            break;
        }
        pNota = pNota->siguienteNota;
    }
    float promedioTotal = acum / 10;
    return promedioTotal;
}

float calcularPromedio()
{
    Alumno* pAlumno = seccion602.alumnos;

    float promedioTotal = 0.0;
    int contador = 0;
    while (pAlumno != NULL)
    {
        float promedio = calcularPromedioAlumno(pAlumno);
        promedioTotal = promedioTotal + promedio;
        contador++;

        pAlumno = pAlumno->siguienteAlumno;
    }

    float promedio = promedioTotal / contador;

    return promedio;
}

void imprimirNotasAlumno(Alumno* pAlumno)
{
    Nota* pNota = pAlumno->notas;

    cout << pAlumno->codigo << "\t\t";

    while(pNota != NULL)
    {
        switch (pNota->tipo)
        {
        case TA:
            cout << "TA:" << pNota->valor << "\t";
            break;
        case EP:
            cout << "EP:" << pNota->valor << "\t";
            break;
        case EF:
            cout << "EF:" << pNota->valor << "\t";
            break;

        default:
            break;
        }

        pNota = pNota->siguienteNota;
    }
    cout << endl;
}

void imprimirSeccion()
{
    Alumno* pAlumno = seccion602.alumnos;

    while (pAlumno != NULL)
    {
        imprimirNotasAlumno(pAlumno);

        pAlumno = pAlumno->siguienteAlumno;
    }
}



int obtenerCantidadAlumnos(){
    if(seccion602.alumnos == NULL){
        return 0;
    }else{
        int cont = 0;
        Alumno* pAlumno = seccion602.alumnos;
        while(pAlumno != NULL){
            cont++;
            pAlumno = (*pAlumno).siguienteAlumno;

        }
        return cont;
    }
}

int main()
{
    // Definimos nuestra seccion
    seccion602.numero = 602;
    seccion602.curso = "Lenguajes de Programacion";
    seccion602.alumnos = NULL;

    // Registrar alumnos
    registrar_alumno("20153434", "Ingenieria de Sistemas");
    registrar_alumno("20171111", "Ingenieria de Sistemas");

    // Registrar notas para los alumnos
    registrar_nota("20153434", 15, TA);
    registrar_nota("20153434", 11, EP);
    registrar_nota("20153434", 20, EF);

    registrar_nota("20171111", 10, TA);
    registrar_nota("20171111", 11, EP);
    registrar_nota("20171111", 11, EF);

    imprimirSeccion();

    return 0;
}
