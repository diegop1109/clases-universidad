#include <iostream>
using namespace std;
struct Fajo
{
    string valor;
    int cantidad;
    Fajo* siguienteFajo;
};
Fajo* generarFajos()
{
    Fajo* f4 = new Fajo();
    f4->cantidad = 6;
    f4->valor = "20";
    f4->siguienteFajo = NULL;

    Fajo* f3 = new Fajo();
    f3->cantidad = 3;
    f3->valor = "50";
    f3->siguienteFajo = f4;

    Fajo* f2 = new Fajo();
    f2->cantidad = 5;
    f2->valor = "20";
    f2->siguienteFajo = f3;

    Fajo* f1 = new Fajo();
    f1->cantidad = 20;
    f1->valor = "10";
    f1->siguienteFajo = f2;

    return f1;
}
int contarDinero (Fajo* Fajo)
{
    int valor = 0;
    if(Fajo->valor == "10")
    {
        valor = 10;
    }else if(Fajo->valor == "20")
    {
        valor = 20;
    }else if(Fajo->valor == "50")
    {
        valor = 50;
    }else
    {
        valor = 0;
    }
    return Fajo->cantidad * valor;
}
int calcularTotalFajo(Fajo* primerFajo)
{
    Fajo* pFajo = primerFajo;
    int total = 0;

    while(pFajo != NULL)
    {
        total += contarDinero(pFajo);
        pFajo=pFajo->siguienteFajo;
    }
    return total;
}
void imprimirTotalesPorValor(Fajo* pFajo)
{
    int total10 = 0, total20 = 0, total50 = 0;
    while(pFajo != NULL)
    {
        if(pFajo->valor == "10") { total10 += contarDinero(pFajo); }
        else if(pFajo->valor == "20") { total20 += contarDinero(pFajo); }
        else { total50 += contarDinero(pFajo); }
        pFajo = pFajo->siguienteFajo;
    }
    cout << "fajo 1: " << total10 << endl;
    cout << "fajo 2: " << total20 << endl;
    cout << "fajo 3: " << total50 << endl;
    cout << "total: " << total10 + total20 + total50 << endl;
}
string obtenerMayorValorFajo(Fajo* pFajo)
{
    int cant10 = 0, cant20 = 0, cant50 = 0;
    while (pFajo != NULL)
    {
        if(pFajo->valor == "10") { cant10 += pFajo->cantidad; }
        else if(pFajo->valor == "20") { cant20 += pFajo->cantidad; }
        else { cant50 += pFajo->cantidad; }
        pFajo = pFajo->siguienteFajo;
    }
    if (cant10 > cant20 && cant10 > cant50) return "10";
    if (cant20 > cant10 && cant20 > cant50) return "20";
    if (cant50 > cant10 && cant50 > cant20) return "50";
    return "";
}
int main()
{
    Fajo* primerFajo = generarFajos();
    int total = calcularTotalFajo(primerFajo);
    cout << "total: " << total << endl;
    imprimirTotalesPorValor(primerFajo);
    cout << "mayor valor: " << obtenerMayorValorFajo(primerFajo) << endl;
    return 0;
}
