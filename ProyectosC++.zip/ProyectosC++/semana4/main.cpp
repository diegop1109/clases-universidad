#include <iostream>
#include "operaciones.hpp"
using namespace std;
using namespace operaciones_decimales;
void sumat(int s1, int s2, int* res)
{
    *res = s1 + s2;
}
int main()
{
    int x = 11;
    int y = 5;
    int res = 0;
    sumat(x,y, &res);
    cout << res << endl;
    return 0;
}
