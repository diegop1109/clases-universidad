#include "operaciones.hpp"
namespace operaciones_decimales
{
    void sumar(int s1, int s2, int* res)
    {
        *res = s1 + s2;
    }
    void restar(int s1, int s2)
    {
    }
}
