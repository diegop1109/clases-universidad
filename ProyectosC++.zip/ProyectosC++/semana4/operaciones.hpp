namespace operaciones_decimales
{
    void sumar(int s1, int s2, int* res);
    void restar(int s1, int s2);
}
