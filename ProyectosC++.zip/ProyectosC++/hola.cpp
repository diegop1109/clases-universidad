#include<string> //importar la libreria para strings
using namespace std; //para poder utilizar los string
#include<iostream> //para poder mostrar en pantalla por medio de "cout"

struct persona
{
        string nombre;
        int edad;
        string telefono;
};

enum DiasSemana
{
    Lunes, Martes, Miercoles, Jueves, Viernes
};

void fibo()
{
    int sec[7];
    for(int i=0; i<7; i++)
    {
        if(i==0 || i==1) sec[i]=1;
        else
        {
            sec[i] = sec[i-1]+sec[i-2];
        }
        cout << "fibo: " << sec[i] << endl;
    }
    return 0;
}
void imprimirDiasSemana()
{
    DiasSemana arr[2];
    arr[0] = Martes;
    arr[1] = Jueves;

    for(int i=0; i<2; i++)
    {
        if(arr[i]=="Lunes"){
            cout << "Lunes"
        }
    }
}
int main()
{
    //tipo dato
    int edad;
    float mont;
    double montopreciso;
    char car;
    string nombre;
    //tipos de datos complejos
    DiasSemana dia;
    persona pepito;
    int numeros[5];

    //asignacion
    edad = 20;
    mont = 23.4;
    car = 'c';
    nombre = "pepe";
    dia = Miercoles;
    pepito.nombre = "pepito";
    numeros[0] = 123;

    cout << "nombre: "<< nombre << endl; cout << "terminar programa" << endl;
    cout << "dia de la semana: " << dia << endl;
    cout << "nombre de persona: " << pepito.nombre << endl;
    return 0;
}
