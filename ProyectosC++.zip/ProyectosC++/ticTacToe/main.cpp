#include <iostream>
using namespace std;
enum Simbolo {nada, cruz, circulo};
struct Casilla
{
    Simbolo simbolo;
    Casilla* CasillaDerecha;
    Casilla* CasillaInferior;
};
Casilla* armarTablero(int tam)
{
    Casilla* pFilaAnterior=NULL;
    Casilla* pPrimeraCasillaFila=NULL;
    for( i=0; i<tam; i++)
    {
        Casilla* pFila= armarFila(tam);
        if(pFilaAnterior!=NULL)
        {
            pFilaAnterior->CasillaInferior = pFila;
        }else
        {
            pPrimeraCasillaFila =pFila;
        }
        pFilaAnterior = pFila;
    }
    return pPrimeraCasillaFila;
}
int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
