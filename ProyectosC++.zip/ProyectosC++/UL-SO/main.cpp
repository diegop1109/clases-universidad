#include <iostream>
using namespace std;
enum Tipo { Entero, Decimal, Booleano };
struct Recurso
{
    Tipo tipo;
    Recurso* siguienteRecurso;
};
struct Proceso
{
    string nombre;
    int pid;
    Proceso* siguienteProceso;
    Recurso* recurso;
};
Proceso* ListaProcesos = NULL;
void createProcess(string nombre)
{
    Proceso* nuevoProceso = new Proceso();
    nuevoProceso->nombre = nombre;
    nuevoProceso->pid = pid++;
    nuevoProceso->recurso =NULL;
    nuevoProceso->siguienteProceso = NULL;
    if(ListaProcesos ==NULL)
    {
        ListaProcesos = nuevoProceso;
    }else
    {
        Proceso* pProceso = ListaProcesos;
        while(pProceso->siguienteProceso != NULL)
        {
            pProceso = pProceso->siguienteProceso;
        }
        pProceso->siguienteProceso = nuevoProceso;
    }
}
void AddResourceToProcess(Tipo tipoRecurso)
{
    Proceso* pProceso = NULL;
    pProceso = ListaProcesos;
    while(pProceso != NULL)
    {
        Recurso* pRecurso = pProceso->recurso;
        Recurso* nuevoRecurso = new Recurso();
        nuevoRecurso->tipo = tipoRecurso;
        nuevoRecurso->siguienteRecurso = NULL;
        if(pProceso->recurso == NULL)
        {
            pRecurso = nuevoRecurso;
        }
        else
        {

        }
    }
}
int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
