using namespace std;
#include<iostream>
int main()
{
    int i=50;
    int* pi=&i;
    cout << pi << endl;
    cout << &i << endl;
    cout << &pi <<endl;
    cout << *pi <<endl;

    cout << "con arreglos:" <<endl;
    int numeros[3];
    numeros[0]=12;
    numeros[1]=345;
    numeros[2]=23;
    cout << *numeros << endl; //devuelve el primer valor del arregglo
    cout << numeros << endl;  // devuelve la direccion de memoria del primer valor
    cout << *(numeros+1) <<endl; //devuelve el valor del segundo valor del arreglo
    //cout << *numeros[0] << endl; //no permite leerlo porque *numeros[0] es lo mismo que *33, deberia decir *(variable)
    return 0;
}
