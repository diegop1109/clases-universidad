#include "holaImperativo.h"

holaImperativo::holaImperativo()
{
    //ctor
}

holaImperativo::~holaImperativo()
{
    //dtor
}
