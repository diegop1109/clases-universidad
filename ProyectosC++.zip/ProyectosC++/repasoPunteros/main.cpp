#include <iostream>
using namespace std;
enum Tipo
{
    TA, EP, EF
};
struct Nota
{
    int valor;
    Tipo tipo;
    Nota* siguienteNota;
};
struct Alumno
{
    string codigo;
    string carrera;
    Alumno* siguienteAlumno;
    Nota* notas;
};
struct Seccion
{
    int numero;
    string curso;
    Alumno* alumnos;
};
Seccion seccion602;
void registrar_alumno(string codigo, string carrera)
{
    Alumno al1;
    al1.carrera=carrera;
    al1.codigo=codigo;
    al1.notas=NULL;
    al1.siguienteAlumno=NULL;

    seccion602.alumnos= &al1;
}
int main()
{
    seccion602.curso="Lenguajes de progrmacion";
    seccion602.numero=602;
    seccion602.alumnos=NULL;
    //ASIGNAR PRIMER ALUMNO
    registrar_alumno("20171160", "ingenieria de sistemas");
    return 0;
}
