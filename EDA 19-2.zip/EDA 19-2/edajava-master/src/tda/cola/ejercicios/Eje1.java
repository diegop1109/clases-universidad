package tda.cola.ejercicios;

public class Eje1 {
    public static void main(String[] args) {
        java.util.Stack<String> pila = new java.util.Stack<String>();
        
        
    }
    
}
