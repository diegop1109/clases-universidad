
package libros;
import java.util.Scanner;

public class Libro {
    //ATRIBUTOS
    private String id;
    private String autor;
    private String titulo;
    private int year;
    //METODOS:
    //Constructores
    public Libro() {
    }
    public Libro(String id, String autor, String titulo, int year) {
        this.id = id;
        this.autor = autor;
        this.titulo = titulo;
        this.year = year;
    }
    //accesadores y modificadores (getters & setters)
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getAutor() {
        return autor;
    }
    public void setAutor(String autor) {
        this.autor = autor;
    }
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }
    //OTROS METODOS

    @Override
    public String toString() {
        return id;
    }
    public void leer(){
        Scanner entrada=new Scanner(System.in);
        System.out.println("ingresar datos del libro: ");
        System.out.println("ingrese el id: "); id=entrada.nextLine();
        System.out.println("ingrese el autor: "); autor=entrada.nextLine();
        System.out.println("ingrese el titulo: "); titulo=entrada.nextLine();
        System.out.println("ingrese el año: "); year=entrada.nextInt();
    }
    //mostrar informacion del libro en una linea/fila
    public void escribir(){
        StringBuilder linea=new StringBuilder(); //StringBuilder - Constructor de cadena
        linea.append(id);                        //append - concatenar una cadena
        linea.append("\t");
        linea.append(autor);
        linea.append("\t");
        linea.append(titulo);
        linea.append("\t");
        linea.append(year);
        System.out.println(linea);
    }
}
