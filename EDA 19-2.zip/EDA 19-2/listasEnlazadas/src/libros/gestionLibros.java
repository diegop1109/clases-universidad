/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libros;

import java.util.Scanner;

public class gestionLibros {
    public static int menu(){
        Scanner entrada=new Scanner(System.in);
        System.out.println("MENU PRINCIPAL");
        System.out.println("1. registrar libro");
        System.out.println("2. buscar libro");
        System.out.println("3. mostrar libros");
        System.out.println("4. eliminar libro");
        System.out.println("5. salir");
        System.out.print("elija una opcion: "); int opcion=entrada.nextInt();
        return opcion;
    }
    public static void main(String[] args) {
        listaLibro biblioteca=new listaLibro();
        boolean terminado=false;
        do{
            switch(menu()){
                case 1: biblioteca.agregarLibro();break;
                case 2: biblioteca.buscarLibro();break;
                case 3: System.out.println("id\tautor\ttitulo\taño");
                        biblioteca.mostrarLibros();break;
                case 4: biblioteca.eliminarLibro(); break;
                case 5: terminado=true; break;
            }
        }while(!terminado);
    }
}
