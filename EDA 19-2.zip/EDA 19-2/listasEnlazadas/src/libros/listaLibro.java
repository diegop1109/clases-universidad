/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libros;
import lista.listaSimple;
public class listaLibro {
    //ATRIBUTOS
    private listaSimple listado;
    //CONSTRUCTORES
    public listaLibro() {
        listado=new listaSimple();
    }

    public listaSimple getListado() {
        return listado;
    }
    public void setListado(listaSimple listado) {
        this.listado = listado;
    }
    
    //OTROS METODOS
    //ubicar la posicion de un elemento en la lista utilizando el identificador del objeto
    public int indice(Object elemento){
        return listado.ubicar(elemento);
    }
    //agregar un libro a la lista
    public void agregarALista(Libro libro){
        if(indice(libro.getId())==0){ //si es igual a 0 entonces el libro no esta almacenado en la lista
            listado.insertar(libro, listado.longitud()+1);
        }else System.out.println("el libro ya existe");
    }
    public void agregarLibro(){
        //crear un objeto libro y leer sus datos
        Libro libro=new Libro();
        libro.leer();
        //agregar el libro a la lista
        agregarALista(libro);
    }
    public void mostrarLibros(){
        for (int i = 1; i <=listado.longitud(); i++) {
            Libro libro=(Libro) listado.iesimo(i);
            libro.escribir();
        }
    }
    public void buscarLibro(){
        java.util.Scanner entrada=new java.util.Scanner(System.in);
        //leer el identificador del libro
        System.out.print("ingrese el id del libro: "); String id=entrada.nextLine();
        //determinar la ubicacion del libro
        int i=indice(id);
        if(i>0){
            Libro libro=(Libro) listado.iesimo(i);
            libro.escribir();
        }else System.out.println("el libro no existe");
    }
    public void eliminarLibro(){
        java.util.Scanner condenado=new java.util.Scanner(System.in);
        System.out.print("ingrese el id del libro a eliminar: "); String id=condenado.nextLine();
        int i=indice(id);
        if(i>0){
            listado.eliminar(i);
        }else System.out.println("no existe");
    }
}
