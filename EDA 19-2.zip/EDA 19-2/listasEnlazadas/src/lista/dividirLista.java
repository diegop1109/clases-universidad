/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista;

public class dividirLista {
    public static void mostrarLista(listaSimple lista){
        //muestra todos los elementos de la lista
        for (int i = 1; i <= lista.longitud(); i++) {
            System.out.println("elemento["+i+"]: "+lista.iesimo(i));
        }
    }
    public static void dividirListas(listaSimple lista, Object nn){
        listaSimple l1=new listaSimple();
        listaSimple l2=new listaSimple();
        int posDividir=lista.ubicar(nn);
        for (int i = 1; i < posDividir; i++) {
            l1.insertar(lista.iesimo(i), i);
        }
        int i=1;
        for (int j = posDividir; j <= lista.longitud(); j++) {
            l2.insertar(lista.iesimo(j), i);
            i++;
        }
        System.out.println("lista 1:");
        mostrarLista(l1);
        System.out.println("lista 2:");
        mostrarLista(l2);
    }
    public static void concatenarListas(listaSimple l1, listaSimple l2){
        int c1=l1.longitud();
        int c2=l2.longitud();
        listaSimple lista=new listaSimple();
        for (int i = 1; i <=c1; i++) {
            lista.insertar(l1.iesimo(i), i);
        }
        int j=c1+1;
        for (int i = 1; i <=c2; i++) {
            lista.insertar(l2.iesimo(i), j);
            j++;
        }
        System.out.println("listas concatenadas");
        mostrarLista(lista);
    }
    public static void invertirLista(listaSimple lista){
        int c=lista.longitud();
        int j=c;
        listaSimple invertida=new listaSimple();
        for (int i = 1; i <=c/2; i++) {
            Object temp=lista.iesimo(i);
            lista.insertar(lista.iesimo(j), i);
            lista.insertar(temp, j);
            j--;
        }
        System.out.println("lista invertida");
        mostrarLista(invertida);
    }
    public static void intercalarListas(listaSimple l2, listaSimple l1){
        int c1=l1.longitud();
        int c2=l2.longitud();
        listaSimple lista3=new listaSimple();
        int j=1;
        int k=1;
        for (int i = 1; i <=c1+c2; i++) {
            if(i%2!=0) {
                lista3.insertar(l1.iesimo(j), i);
                j++;
            }else{
                lista3.insertar(l2.iesimo(k), i);
                k++;
            }
        }mostrarLista(lista3);
    }
    public static boolean ordenada(listaSimple l){
        for (int i = 1; i <l.longitud(); i++) {
            int c=(int) l.iesimo(i);
            int c2=(int) l.iesimo(i+1);
            if(c>c2) return false;
        }return true;
    }
    public static void main(String[] args) {
        listaSimple lista=new listaSimple();
        lista.insertar(1, 1);
        lista.insertar(2, 2);
        lista.insertar(3, 3);
        lista.insertar(4, 4);
        lista.insertar(5, 5);
        mostrarLista(lista);
        //dividirListas(lista, "d");
        listaSimple lista2=new listaSimple();
        lista2.insertar("a", 1);
        lista2.insertar("b", 2);
        lista2.insertar("c", 3);
        lista2.insertar("d", 4);
        lista2.insertar("e", 5);
        mostrarLista(lista2);
        //concatenarListas(lista, lista2);
        invertirLista(lista);
        //System.out.println("intercalar listas:");
        //intercalarListas(lista2, lista);
        //System.out.println("la lista(1) esta ordenada ascendentemente? "+ordenada(lista));
    }
}
