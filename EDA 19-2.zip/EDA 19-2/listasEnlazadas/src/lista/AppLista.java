/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista;

/**
 *
 * @author R4604
 */
public class AppLista {
    public static void main(String[] args) {
        //crear una lista
        listaSimple lista1=new listaSimple();
        lista1.insertar("ana",1);
        lista1.insertar("carlos", 2);
        lista1.insertar("juana", 3);
        lista1.insertar("marcelo", 2);
        listaSimple lista2=new listaSimple();
        lista2.insertar("ana",1);
        lista2.insertar("carlos", 2);
        lista2.insertar("juana", 3);
        lista2.insertar("marcelo", 2);
        System.out.println("lista 1 y lista 2 son iguales?: "+lista1.sonIguales(lista2));
        //mostrar elementos de la lista
        for (int i = 1; i <= lista1.longitud(); i++) {
            System.out.println("elemento["+i+"]: "+lista1.iesimo(i));
        }
        System.out.println("eliminar elemento en la posicion 3  e insertamos un nuevo elemento en esa posicion");
        lista1.eliminar(3);
        lista1.insertar("roberto", 3);
        for (int i = 1; i <= lista1.longitud(); i++) {
            System.out.println("elemento["+i+"]: "+lista1.iesimo(i));
        }
        System.out.println("ubicacion de roberto: "+lista1.ubicar("roberto"));
        
        listaSimple lista3=new listaSimple();
        lista3.insertar(1,1);
        lista3.insertar(2, 2);
        lista3.insertar(3, 3);
        lista3.insertar(4, 4);
        System.out.println("la lista3 esta ordenada? "+lista3.ordenada());
    }
}
