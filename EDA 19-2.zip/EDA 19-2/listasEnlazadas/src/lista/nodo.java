/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista;

public class nodo {
    private Object elemento;
    private nodo sig;

    public nodo() {
    }
    public nodo(Object elemento, nodo sig) {
        this.elemento = elemento;
        this.sig = sig;
    }

    public Object getElemento() {
        return elemento;
    }
    public void setElemento(Object elemento) {
        this.elemento = elemento;
    }
    public nodo getSig() {
        return sig;
    }
    public void setSig(nodo sig) {
        this.sig = sig;
    }
    
}
