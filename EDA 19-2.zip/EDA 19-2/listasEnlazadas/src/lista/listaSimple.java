/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista;

public class listaSimple {
    private nodo primerNodo;
    
    public listaSimple(){
        this.primerNodo=new nodo();
    }
    public listaSimple(Object elemento, nodo sig){
        this.primerNodo.setElemento(elemento);
        this.primerNodo.setSig(sig);
    }
    public nodo getPrimerNodo() {
        return primerNodo;
    }
    public void setPrimerNodo(nodo primerNodo) {
        this.primerNodo = primerNodo;
    }
    /////////////////////////////////////////////////////////////
    //metodo "esVacia": identifica si la lista esta vacia o no
    public boolean esVacia(){
        if(primerNodo.getElemento()==null && primerNodo.getSig()==null) return true;
        else return false;
    }
    //insertar: coloca elementos a la lista
    public void insertar(Object elemento, int posicion){
        //caso en el que se quiere insertar en la posicion 1
        if(posicion==1){
            //caso1: la lista esta vacia
            if(esVacia()) primerNodo.setElemento(elemento);
            else{//caso 2: la lista no esta vacia
                //llamamos al primer nodo y creamos uno nuevo/auxiliar
                Object actualElemento=primerNodo.getElemento();
                nodo punteroSig=primerNodo.getSig();
                nodo nodoAux=new nodo(actualElemento, punteroSig);
                primerNodo.setSig(nodoAux);
                primerNodo.setElemento(elemento);
            }
        }else{// posicion>1
            //buscar la posicion a insertar
            nodo nodoAux=primerNodo;
            int i=1;
            //ubicamos al nodo ubicado en la posicion anterior a la que se desea ubicar
            while(i<posicion-1){
                //avanzar al siguiente nodo
                nodoAux=nodoAux.getSig();
                i++;
            }
            //crear un nuevo nodo a insertar
            nodo nuevoNodo=new nodo(elemento,nodoAux.getSig());
            nodoAux.setSig(nuevoNodo);
        }
    }
    /*iesimo: recupera el iesimo elemento de la lista
     *precondicion: 1<=posicion<=longitud
    */
    public Object iesimo(int posicion){
        nodo nodoAux=primerNodo;
        int i=1;
        while(i<posicion){
            nodoAux=nodoAux.getSig();
            i++;
        }return nodoAux.getElemento();
    }
    /*
    * longitud(contar elementos): determina la longitud/cantidad de elementos de la lista
    */
    public int longitud(){
        if(esVacia()) return 0;
        else{
            nodo nodoAux=primerNodo;
            int i=1;
            while(nodoAux.getSig()!=null){
                nodoAux=nodoAux.getSig();
                i++;
            }return i;
        }
    }
    /*
     * ubicar: devuelve una posicion, dado un elemento(el contrario al iesimo)
    */
    public int ubicar(Object elemento){
        if(esVacia()) return 0;
        else{
            nodo nodoAux=primerNodo;
            int i=1;
            while(!(nodoAux.getElemento().toString().equals(elemento)) && i<=longitud()){
                i++;
                if(nodoAux.getSig()==null) return 0;
                else nodoAux=nodoAux.getSig();
            }return i;
        }
    }
    /*
    * eliminar: indicamos la posicion del nodo que queramos eliminar
    * precondicion: 1<=posicion<=tamaño de la lista
    */
    public void eliminar(int posicion){
        if(posicion>=1 && posicion<=longitud()){
            nodo nodoAux=primerNodo;
            int i=1;
            while(i<posicion-1){
                nodoAux=nodoAux.getSig();
                i++;
            }
            //eliminar 
            /*forma 1: 
            * con un nodoAux2=nodoAux.siguiente
            * nodoAux.setSiguiente(nodoAux2.siguiente)
            */
            //forma 2:
            nodo nodoAux2 = nodoAux.getSig();
            nodoAux.setSig(nodoAux2.getSig());
        }
    }
    public boolean sonIguales(listaSimple lista){
        nodo nodoAux = primerNodo;
        nodo nodoAux2 = lista.primerNodo;
        while(nodoAux.getSig()!=null){
            if(nodoAux.getElemento()!=nodoAux2.getElemento()) return false;
            nodoAux=nodoAux.getSig();
            nodoAux2=nodoAux2.getSig();
        }return true;
    }
    /*
     * invertir lista: devolveremos los elementos de una lista de forma inversa
    
    public void invertirLista(){
        int c=longitud();
        int j=c;
        nodo nodoAux=primerNodo;
        listaSimple lista=new listaSimple();
        while (nodoAux.getSig()!=null) {
        }
    }*/
    /*
    *   ordenada: verificar si la lista de enteros esta ordenada ascendentemente
    */
    public boolean ordenada(){
        nodo nodoAux=primerNodo;
        while(nodoAux.getSig()!=null){
            int a=(int) nodoAux.getElemento();
            int b=(int) nodoAux.getSig().getElemento();
            if(a>b) return false;
            nodoAux=nodoAux.getSig();
        }return true;
    }
}
