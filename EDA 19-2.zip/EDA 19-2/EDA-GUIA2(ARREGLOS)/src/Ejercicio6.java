/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B3106
 */
public class Ejercicio6 {
    public static void main(String[] args) {
        int[] a={2,5,6,7,9,12,14,34,55};
        int[] b={0,1,4,8,11,22,30,60};
        Mezclar(a,b);
    }
    public static void Mezclar(int[] a, int[] b){
        int m=a.length, n=b.length;
        int[] c=new int[m+n];
        //usaremos 3 contadores (uno por cada arreglo) para coger los datos de cada uno de los arreglos
        int i=0; int j=0; int k=0;
        while (i<a.length && j<b.length) {            
            if (a[i]<b[j]) {
                c[k]=a[i];
                i++;
            }else{
                c[k]=b[j];
                j++;
            }k++;
        }
        while (i<a.length) {            
            c[k]=a[i];
            k++;
            i++;
        }
        while (j<b.length) {            
            c[k]=b[j];
            k++;
            j++;
        }
        for (int l = 0; l < c.length; l++) {
            System.out.print(" "+c[l]);
        }
    }
}
