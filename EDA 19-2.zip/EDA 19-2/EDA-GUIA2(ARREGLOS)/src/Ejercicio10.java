
import java.util.Random;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author MIRIAM
 */
public class Ejercicio10 {
    public static void main(String[] args) {
        int[] r=new int[30];
        int[] inv=new int[30];
        Random rnd=new Random();
        for (int i = 0; i < r.length; i++) {
            r[i]=(int)(rnd.nextInt(100));
            System.out.print(r[i]+", ");
        }
        System.out.println("");
        int a=1;
        for (int i = 0; i < r.length; i++) {
            inv[i]=r[r.length-a];
            System.out.print(inv[i]+", ");
            a++;
        }
        System.out.println("");
        int b=1;
        for (int i = 0; i < r.length/2; i++) {
            int temp = r[i]; 
            r[i]=r[r.length-b];
            r[r.length-b] = temp;
            b++;
        }
        for (int i = 0; i < r.length; i++) {
            System.out.print(r[i]+", ");
        }
    }
}
