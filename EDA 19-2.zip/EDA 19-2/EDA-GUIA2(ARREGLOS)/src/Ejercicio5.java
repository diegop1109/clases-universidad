/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B3106
 */
public class Ejercicio5 { //comparar dos arreglos igualdad, mayoria o minoria
    public static void main(String[] args) {
        int[] a={2,3,4,5,7};
        int[] b={1,2,3,4,5};
        //System.out.println("valor: "+Comparar(a,b));
        //aqui el profesor implemento una funcion llamada "comparar"
        //tambien es posible usarlo de esta manera
        /*if (a.length==b.length) {
            if(sonIguales(a,b)) System.out.println("respuesta: 1");
            else{
                if(AesMenorB(a,b)) System.out.println("repuesta: 2");
                else{
                    if(AesMayorB(a,b)) System.out.println("repuesta: 3");
                    else System.out.println("respuesta: 0");
                }
            }
        }else System.out.println("repuesta: 0");*/
    }
    public static int Comparar(int[] a, int[] b){
        if (a.length==b.length) {
            if(sonIguales(a,b)) return 1;
            else{
                if(AesMenorB(a,b)) return 2;
                else{
                    if(AesMayorB(a,b)) return 3;
                    else return 0;
                }
            }
        }else return 0;
    }
    
    public static boolean sonIguales(int[] a, int[] b){
        for (int i = 0; i < a.length; i++) {
            if(a[i]!=b[i]) return false;
        }
        return true;
    }
    public static boolean AesMenorB(int[] a, int[] b){
        for (int i = 0; i < a.length; i++) {
            if(!(a[i]<b[i])) return false;
        }
        return true;
    }
    public static boolean AesMayorB(int[] a, int[] b){
        for (int i = 0; i < a.length; i++) {
            if(!(a[i]>b[i])) return false;
        }
        return true;
    }
}
