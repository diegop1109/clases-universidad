/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B3106
 */
public class Ejercicio2 { //calcular la cantidad de numeros pares de un arreglo
    public static void main(String[] args) {
        int[] a={1,5,2,8,3,79,4}; //n=7 elementos
        int c=0;
        //importante: recorrer el arreglo
        for (int i = 0; i < a.length; i++) {
            if (a[i]%2==0) c++;
        }
        System.out.println("numero de pares en el arreglo es de: "+c);
    }
}
