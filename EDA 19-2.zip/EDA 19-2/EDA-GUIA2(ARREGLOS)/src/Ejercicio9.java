/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MIRIAM
 */
import java.util.Random;
public class Ejercicio9 {
    public static void main(String[] args) {
        int[] x=new int[50]; Random rnd=new Random();
        int [] dx= new int[x.length-1];
        for (int i = 0; i < x.length; i++) {
            x[i]=(int) (rnd.nextInt(10));
            System.out.print(x[i]+", ");
        }System.out.println("");
        for (int j = 0; j < x.length-1; j++) {
            dx[j]=x[j]-x[j+1];
            System.out.print(dx[j]+", ");
        }
    }
}
