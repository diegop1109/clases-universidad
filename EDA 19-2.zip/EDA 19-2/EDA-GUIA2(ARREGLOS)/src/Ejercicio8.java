/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MIRIAM
 */
public class Ejercicio8 {
    public static void main(String[] args) {
        int notas[]={12,13,14,6,11,20,18,8,9,10};
        sobreElPromedio(notas);
    }
    public static void sobreElPromedio(int[] notas){
        int c=0;
        int b=0;
        for (int i = 0; i < notas.length; i++) {
            c=c+notas[i];
        } System.out.println("promedio: "+c/notas.length);
        for (int i = 0; i < notas.length; i++) {
            if(notas[i]>(c/notas.length)) b++;
        } System.out.println("son "+b+" alumnos los que estan por encima del promedio");
    }
}
