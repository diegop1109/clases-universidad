/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B3106
 */
public class Ejercicio4 { //determinar el maximo y minimo elemento de un arreglo
    public static void main(String[] args) {
        int[] a={1,5,67,32,8,0,-9};
        //declaramos variables y asumimos que al iniciar 
        //el maximo y minimo tomaran el primer elemento
        int max=a[0], min=a[0];
        //recorrer el arreglo
        for (int i = 1; i < a.length; i++) {
            //para el mayor:
            if(a[i]>max) max=a[i];
            //para el menor:
            if(a[i]<min) min=a[i];
        }
        System.out.println("el mayor numero dentro de arreglo es: "+max);
        System.out.println("el minimo valor dentro del arreglo es: "+min);
    }
}
