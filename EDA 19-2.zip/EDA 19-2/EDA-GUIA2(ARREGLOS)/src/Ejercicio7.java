/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MIRIAM
 */
public class Ejercicio7 {
    public static void main(String[] args) {
        String n[]={"edgardo","luis","Marieta"};
        String s[]={"M","M","F"};
        int e[]={45,18,1};
        System.out.println("promedio de edades: "+edadProm(e));
        System.out.println("profesor mas viejo: "+n[masViejo(e)]);
        profesorM(n);
    }
    public static int edadProm(int[] e){
        int a=e.length; int c=0;
        for (int i = 0; i < a; i++) {
            c=c+e[i];
        }return c/a;
    }
    public static int masViejo(int[] e){
        int a=e.length; int c=0;
        int pos=0;
        for (int i = 0; i < a; i++) {
            if(e[i]>c){
                c=e[i];
                pos=i;
            }
        }return pos;
    }
    public static void profesorM(String[] n){
        int a=n.length;
        char b[]={};
        
        System.out.println(n[0].charAt(0));
        System.out.println(n[0].equals("ana"));
    }
}
