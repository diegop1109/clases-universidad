/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author R4604
 */
import java.util.Random;
import java.util.Scanner;
public class AppMatriz {
    static Scanner entrada=new Scanner(System.in);
    //el parametro es una matriz vacia meteremos nuevos datos
    public static void LeerMatriz(int[][] matriz){
        for (int fila = 0; fila < matriz.length; fila++) {
            for (int columna = 0; columna < matriz[fila].length; columna++) {
                System.out.print("item["+fila+"]["+columna+"]: ");
                matriz[fila][columna]=entrada.nextInt();
            }
        }
    }
    public static void mostrarMatriz(int[][] matriz){
        for (int fila = 0; fila < matriz.length; fila++) {
            for (int columna = 0; columna < matriz[fila].length; columna++) {
                System.out.print(matriz[fila][columna]+"\t");
            } System.out.println();
        }
    }
    public static int[][] matrizAleatoria(int fila, int columna){
        int[][] matriz=new int[fila][columna];
        for (int i = 0; i < matriz.length; i++) { //filas
            for (int j = 0; j < matriz[i].length; j++) { //columnas
                matriz[i][j]=(int)(Math.random()*100);
            }
        }return matriz;
    }
    public static int[] arregloAleatorio(int tamaño){
        int[] r=new int[tamaño];
        Random rnd=new Random();
        for (int i = 0; i < r.length; i++) {
            r[i]=(int)(rnd.nextInt(100));
        }return r;
    }
    public static int sumarMatriz(int[][] matriz){
        int sum=0;
        for (int fila = 0; fila < matriz.length; fila++) {
            for (int columna = 0; columna < matriz[fila].length; columna++) {
                sum=sum+matriz[fila][columna];
            }
        }return sum;
    }
    public static void sumarFilas(int[][] matriz){
        for (int  i= 0;  i< matriz.length; i++) {
            int sf=0;
            for (int columna = 0; columna < matriz[i].length; columna++) {
                sf=sf+matriz[i][columna];
            }System.out.println("fila["+i+"]: "+sf);
        }
    }
    public static void sumarColumnas(int[][] matriz){
        for (int columna = 0; columna < matriz[0].length; columna++) {
            int sc=0;
            for (int fila = 0; fila < matriz.length; fila++) {
                sc=sc+matriz[fila][columna];
            }System.out.println("columna["+columna+"]:"+sc);
        }
    }
    public static boolean simetrica(int[][] matriz){ //si la matriz es simetrica devuelve 1, sino 0
        for (int fila = 0; fila < matriz.length; fila++) {
            for (int columna = 0; columna < matriz[fila].length; columna++) {
                if(matriz[fila][columna]!=matriz[columna][fila]) return false;
            }
        } return true;
    }
    public static void sumarPorFila(int[][] matriz, int fila){
        int c=0;
        for (int columna = 0; columna < matriz[fila].length; columna++) {
            c=c+matriz[fila][columna];
        }System.out.println("fila["+fila+"]:"+c);
    }
    public static void sumarPorColumna(int[][] matriz, int columna){
        int c=0;
        for (int fila = 0; fila < matriz.length; fila++) {
            c=c+matriz[fila][columna];
        }System.out.println("columna["+columna+"]:"+c);
    }
    //ejercicio 2: guia
    //2a
    public static void ventasTrujillo(int[][] matriz, int columna){
        int v=0;
        for (int fila = 0; fila < matriz.length; fila++) {
            v=v+matriz[fila][columna];
        }System.out.println("ventas Trujillo:"+v);
    }
    public static float promedioDiciembre(int[][] matriz, int fila){
        float c=0;
        float p=0;
        for (int columna = 0; columna < matriz[fila].length; columna++) {
            c=c+matriz[fila][columna];
            p++;
        }return c/p;
    }
    public static void ganadorMayo(int[][] matriz, int fila){
        int mayor=0;
        int col=0;
        for (int columna = 0; columna < matriz[fila].length; columna++) {
            if(matriz[fila][columna]>mayor){
                mayor=matriz[fila][columna];
                col=columna;
            }
        }
        if(col==0) System.out.println("Trujillo con "+mayor+" obtuvo las mayores ventas en mayo");
        else{
            if(col==1) System.out.println("Lima con "+mayor+" obtuvo las mayores ventas en mayo");
            else{
                if(col==2) System.out.println("Tacna con "+mayor+" obtuvo las mayores ventas en mayo");
                else{
                    if(col==3) System.out.println("Cuzco con "+mayor+" obtuvo las mayores ventas en mayo");
                    else System.out.println("Piura con "+mayor+" obtuvo las mayores ventas en mayo");
                }
            }
        }
    }
    //ejercicio 3
    public static void losDosGrandes(){
        String[] a={"alberto","sergio","marieta","augusto","juancito","leonardo"};
        int[][] notas=new int[a.length][5];
        int[] dos=new int[a.length];
        //rellenar matriz
        for (int i = 0; i < notas.length; i++) {
            for (int j = 0; j < notas[0].length; j++) {
                notas[i][j]=(int) (Math.random()*20);
            }
        }
        for (int i = 0; i < notas.length; i++) {
            for (int j = 0; j < notas[0].length; j++) {
                System.out.print(notas[i][j]+"\t");
            }System.out.println("");
        }
        for (int i = 0; i < notas.length; i++) {
            int sf=0;
            int men=20;
            
            for (int j = 0; j < notas[0].length; j++) {
                if(notas[i][j]<men) men=notas[i][j];
            }
            for (int j = 0; j < notas[0].length; j++) {
                sf=sf+notas[i][j];
            }System.out.println("promedio de "+a[i]+" es: "+(sf-men)/4);
            dos[i]=(sf-men)/4;
        }
        //no me regresa loss nombres de los mejores estudiantes
        //pero si regresa los dos mejores promedios
        for (int i = 0; i < dos.length-1; i++) {
            for (int j = 0; j < dos.length-i-1; j++) {
                if (dos[j]<dos[j+1]) {
                    int aux=dos[j+1];
                    dos[j+1]=dos[j];
                    dos[j]=aux;
                }
            }
        }System.out.print("mejores promedios: "+dos[0]+" y "+dos[1]);
    }
    public static void accidentesA(int[][] matriz, int año){ //ejercicio 4: los dos distritos con 
        //mayor cantidad de accidentes en un año especificado
        int c=0; int b=0; int a=0; int d=0;
        for (int columnas = 0; columnas < matriz[año].length; columnas++) {
            if(matriz[año][columnas]>c){
                c=matriz[año][columnas];
                a=columnas;
            }
            if(matriz[año][columnas]>b && matriz[año][columnas]<c){
                b=matriz[año][columnas];
                d=columnas;
            }
        }System.out.println("los dos mayores son: el distrito ["+d+"] con "+b+" y "+"el distrito ["+a+"] con "+c);
    }
    //ejercicio 5: ventas a domicilio
    public static void ventasDomicilio(int[][] ventas, int[] precios){
        int c=0;
        int mayor=0;
        for (int vendedor = 0; vendedor < ventas.length; vendedor++) {
            int sum=0;
            for (int producto = 0; producto < 10; producto++) {
                sum=sum+(ventas[vendedor][producto]*precios[producto]);
                if(sum>mayor){
                    mayor=sum;
                    c=vendedor;
                }
            }System.out.println("vendedor ["+(vendedor+1)+"] obtuvo: "+sum+" rupias");
        }System.out.println("el vendedor ["+(c+1)+"] obtuvo la myor cantidad de ventas");
    }
    public static void masVendido(int[][] ventas,int[] precios){
        int mayor=0;
        int prod=0;
        for (int productos = 0; productos < ventas[0].length; productos++) {
            int sum=0;
            for (int vendedores = 0; vendedores < ventas.length; vendedores++) {
                sum=sum+(ventas[vendedores][productos]);
                if(sum>mayor){
                    prod=productos;
                    mayor=sum;
                }
            }
        }System.out.println("el producto ["+prod+"] tuvo un total de "+mayor+" ventas");
    }
    //ejercicio 6: elecciones de presidente
    public static void totalVotos(int[][] elecciones){
        int total=0;
        float[] votos=new float[elecciones.length];
        for (int candidatos = 0; candidatos < elecciones.length; candidatos++) {
            int tv=0;
            for (int provincia = 0; provincia < elecciones[0].length; provincia++) {
                tv=tv+elecciones[candidatos][provincia];
            }votos[candidatos]=tv;
            total=total+tv;
        }System.out.println("total de votos: "+total);
        int presi=0; int presi2=0;
        int a=0; int b=0;
        float c=0; float d=0;
        for (int i = 0; i < votos.length; i++) {
            System.out.println("el candidato ["+(i+1)+"] obtuvo: "+votos[i]+" votos ("+(votos[i]*100/total)+"%)");   
        }
        for (int i = 0; i < votos.length; i++) {
            for (int j = 0; j < votos.length; j++) {
                if(votos[j]>presi){
                    presi=(int) votos[j];
                    a=j+1;
                    c=votos[j]*100/total;
                }
                if((votos[j]>=presi2 && presi2<=presi)){
                    presi2=(int) votos[j];
                    b=j+1;
                    d=votos[j]*100/total;
                }
            }
        }
        System.out.println("el candidato ["+a+"] obtuvo la mayor cantidad de votos");
        if(c>=50) System.out.println("el candidato ["+a+"] ha ganado las elecciones");
        else System.out.println("el candidato ["+a+"] y el candidato ["+b+"] pasaran a segunda ronda");
    }
    public static void main(String[] args) {
        /*int[][] matriz=new int[3][5];
        LeerMatriz(matriz);
        mostrarMatriz(matriz);
        System.out.println("sumatoria de todos los elementos de la matriz: "+sumarMatriz(matriz));
        sumarFilas(matriz);
        sumarColumnas(matriz);
        System.out.println("");
        if(simetrica(matriz)) System.out.println("simetria=1");
        else System.out.println("asimetria=0");
        System.out.println("");
        sumarPorFila(matriz, 0);
        sumarPorColumna(matriz, 0);*/
        
        //matriz Aleatoria(si funcina :y)
        /*int[][] matrizA=matrizAleatoria(12, 5);
        mostrarMatriz(matrizA);
        ventasTrujillo(matrizA, 0);
        System.out.println("promedio de diciembre: "+promedioDiciembre(matrizA, 11));
        ganadorMayo(matrizA, 4);
        losDosGrandes();
        System.out.println("");*/
        
        int[][] accidentes=matrizAleatoria(10, 10);
        mostrarMatriz(accidentes);
        accidentesA(accidentes, 4);
        
        /*int[][]ventas=matrizAleatoria(50, 10);
        int[] precio=arregloAleatorio(10);
        ventasDomicilio(ventas, precio);
        masVendido(ventas, precio);*/
        
        int[][] elecciones=matrizAleatoria(5, 16);
        totalVotos(elecciones);
    }
}
