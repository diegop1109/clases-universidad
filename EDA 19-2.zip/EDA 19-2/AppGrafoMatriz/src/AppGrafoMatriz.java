public class AppGrafoMatriz {
    public static void main(String[] args) {
        GrafoMatriz g=new GrafoMatriz(0, 5, true);
        g.adicionarVertice();
        g.adicionarVertice();
        g.adicionarVertice();
        g.adicionarVertice();
        g.adicionarVertice();
        g.adicionarArco(0, 1);
        g.adicionarArco(1, 2);
        g.adicionarArco(1, 3);
        g.adicionarArco(3, 2);
        g.adicionarArco(3, 0);
        g.adicionarArco(0, 3);
        g.adicionarArco(2, 4);
        g.adicionarArco(3, 4);
        g.mostrarMatriz();
        System.out.println("numero total de arcos de un vertice:");
        System.out.println(g.numArcos());
        System.out.println("");
        System.out.println("eliminar un arco:");
        g.eliminarArco(3, 4);
        g.mostrarMatriz();
        System.out.println("mostrar las entradas de un vertice: "+g.arcosEntrada(3));
        System.out.println("numero total de arcos de un vertice: "+g.numArcos());
        
        GrafoMatriz gND=new GrafoMatriz(0, 5, false);
        gND.adicionarVertice();
        gND.adicionarVertice();
        gND.adicionarVertice();
        gND.adicionarVertice();
        gND.adicionarArco(0, 1);
        gND.adicionarArco(0, 2);
        gND.adicionarArco(0, 3);
        gND.adicionarArco(1, 2);
        gND.adicionarArco(1, 3);
        gND.adicionarArco(2, 3);
        System.out.println("");
        System.out.println("grafo no dirigido");
        gND.mostrarMatriz();
        System.out.println("arcos del no dirigido: "+gND.numArcos());
    }
}
