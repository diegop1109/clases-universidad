public class GrafoMatriz {
    //atributos
    //numero de vertices del grafo
    private int numVertices;
    //maximo numero de vertices en el grafo
    private int maxVertices;
    //matriz de adyacencia del grafo
    Float[][] matriz;
    //indica si es un grafo dirigido o no dirigido
    boolean dirigido;
    //crear un grafo
    public GrafoMatriz(int n, int max, boolean d){
        this.maxVertices=max;
        this.numVertices=n;
        this.matriz=new Float[maxVertices][maxVertices];
        dirigido=d;
    }
    //añadir un vertice
    public void adicionarVertice(){
        if(numVertices==maxVertices){
            System.out.println("Es imposible que eso entre en mi onii-chan!!");
            return;
        }
        //incrementar el numero de vertices
        numVertices++;   
    }
    //añadir un arco SIN PESO
    public void adicionarArco(int i, int j){
        adicionarArco(i, j, 0);
    }
    public void adicionarArco(int i, int j, float peso){
        matriz[i][j]=peso;
        //si es un grafo NO DIRIGIDO tambien debe agregarse un arco simetrico
        if(!dirigido){
            matriz[j][i]=peso;
        }
    }
    public void mostrarMatriz(){
        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                System.out.print(matriz[i][j]+"\t");
            }System.out.println("");
        }
    }
    public void eliminarArco(int i, int j){
        matriz[i][j]=null;
        if(!dirigido) matriz[j][i]=null;
    }
    public int arcosEntrada(int i){
        int c=0;
        for (int j = 0; j < numVertices; j++) {
            if(matriz[j][i]!=null) c++;
        }return c;
    }
    public int numArcos(){
        int c=0;
        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                if(matriz[i][j]!=null) c++;
            }
        }
        if(!dirigido)return c/2;
        else return c;
    }
}
