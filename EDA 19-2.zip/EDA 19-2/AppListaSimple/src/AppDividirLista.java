
public class AppDividirLista {
    public static void mostrarLista(ListaSimple l){
        // Mostrar los elementos de la lista
        for (int i=1;i<=l.longitud();i++){
            System.out.println("Elemento: ("+i+"): "+l.iesimo(i));
        }
    }
    public static void dividirLista(ListaSimple l, Object nn){
        ListaSimple l1 = new ListaSimple();
        ListaSimple l2 = new ListaSimple();
        int posDividir = l.ubicacion(nn);
        for (int i=1;i<posDividir;i++){
            l1.insertar(l.iesimo(i), i);
        }
        int j=1;
        for (int i=posDividir;i<=l.longitud();i++){
            l2.insertar(l.iesimo(i), j);
            j++;
        }
        System.out.println("Lista L1: ");
        mostrarLista(l1);
        System.out.println("Lista L2: ");
        mostrarLista(l2);
    }
    public static void main(String[] args) {
        ListaSimple l = new ListaSimple();
        l.insertar("a", 1);
        l.insertar("b", 2);
        l.insertar("c", 3);
        l.insertar("d", 4);
        l.insertar("e", 5);
        System.out.println("Lista L: ");
        mostrarLista(l);
        dividirLista(l,"c");
        
    }
    
}
