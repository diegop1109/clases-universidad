public class AppLista {
    public static void main(String[] args) {
        // Crear una Lista
        ListaSimple l = new ListaSimple();
        // Inserar elemento en la lista
        l.insertar("ana", 1);
        l.insertar("juna", 2);
        l.insertar("carlos", 3);
        l.insertar("paul", 1);
        // Mostrar los elementos de la lista
        for (int i=1;i<=l.longitud();i++){
            System.out.println("Elemento: ("+i+"): "+l.iesimo(i));
        }
        System.out.println("Eliminar el elemento en la posicion 3.");
        // Eliminar elementos
        l.eliminar(3);
        l.insertar("roberto", 3);
        // Mostrar los elementos de la lista
        for (int i=1;i<=l.longitud();i++){
            System.out.println("Elemento: ("+i+"): "+l.iesimo(i));
        }
        System.out.println("Ubicacion de roberto: "+l.ubicacion("roberto"));
   
    }
    
}
