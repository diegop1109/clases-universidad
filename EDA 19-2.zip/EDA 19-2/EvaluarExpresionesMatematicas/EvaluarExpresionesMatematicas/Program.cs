﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluarExpresionesMatematicas
{
    class Program
    {
        static void Main(string[] args)
        {            
           
            Console.Write("expresion infija: ");
            string exp = Console.ReadLine(); 
            Evaluador e = new Evaluador(exp); 
            //string pf = e.ConvertirInfija(exp);
            double r = e.F();
            Console.WriteLine("expresion postfija: " + e.PostFija );
            Console.WriteLine("resultado: {0}", r);

            Console.ReadLine();
        }

        
    }
}
