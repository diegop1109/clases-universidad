/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class TDACola {
    private int[] C; //Cola representada con arreglos
    private int frente; //pricipio de la cola
    private int ultimo; //final de la cola
    //Constructor: crear una cola
    public TDACola(int longitud){
        this.frente=-1;
        this.ultimo=-1;
        this.C=new int[longitud];
    }
    
    //operacion de Cola Vacía
    public boolean colaVacia(){
        boolean estado=false;
        if(frente==-1 && ultimo==-1) estado=true;
        return estado;
    }
    //operacion de cola llena (aplicable solo a arreglos, pues tienen un tamaño maximo)
    public boolean colaLlena(){
        boolean estado=false;
        int TAM=C.length-1;
        if((frente==0 && ultimo==TAM) || frente==ultimo+1) estado=true; //"frente=ultimo+1" hace referencia al caso en que 
        return estado;                                                  //solo queden 2 elementos en el arreglo
    }
    //operacion encolar elemento (al final) de la cola
    public void encolar(int item){
        int TAM=C.length-1;
        if(!colaLlena()){
            if(colaVacia()){
                frente=0;
                ultimo=0;
            }else{
                if(ultimo==TAM) ultimo=0;
                else ultimo=ultimo+1;
            }
            C[ultimo]=item;
        }
    }
    //operacion desencolar elemento (al frente) de la cola
    public int desencolar(){
        int condenado=C[frente];
        int TAM=C.length-1;
        if(frente==ultimo){
            frente=-1;
            ultimo=-1;
        }else{
            if(frente==TAM) frente=0;
            else frente=frente+1;
        }
        return condenado;
    }
}
