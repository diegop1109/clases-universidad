/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class PruebaCola {
    public static void main(String[] args) {
        TDACola cola=new TDACola(4);
        cola.encolar(25);
        cola.encolar(10);
        cola.encolar(2);
        cola.encolar(3);
        System.out.println("cola llena? "+cola.colaLlena());
        /*System.out.println("desencolar: "+cola.desencolar()); //desencola el 25
        cola.encolar(5);
        System.out.println("desencolar: "+cola.desencolar()); //desencola el 10
        System.out.println("desencolar: "+cola.desencolar());
        System.out.println("desencolar: "+cola.desencolar());
        System.out.println("desencolar: "+cola.desencolar());
        System.out.println("cola llena? "+cola.colaVacia());*/
        int n=0;
        while(!cola.colaVacia()){
            int item=cola.desencolar();
            if(item%2==0) n++;
        }System.out.println("numero de elementos pares en la cola: "+n);
    }
}
