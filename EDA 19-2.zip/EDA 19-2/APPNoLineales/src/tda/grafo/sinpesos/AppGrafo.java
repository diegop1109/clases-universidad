package tda.grafo.sinpesos;

public class AppGrafo {

    public static void main(String[] args) {
        Grafo g = new Grafo();
        Vertice v1 = new Vertice("a");
        Vertice v2 = new Vertice("b");
        Vertice v3 = new Vertice("c");

        g.agregarVertice(v1);
        g.agregarVertice(v2);
        g.agregarVertice(v3);

        g.agregarArco(v1, v2);
        g.agregarArco(v1, v3);
        g.agregarArco(v2, v3);

        g.mostrarGrafo();
    }

}
