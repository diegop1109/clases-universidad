package tda.grafo.matriz;

//Implementacion de Grafos con matriz de adyacencia.
public class GrafoMatriz {

    //numero de vertices del grafo
    int numVertices;
    //Maximo numero de vertices del grafo
    int maxVertices;
    //Matriz de adyacencia con Clase Float - Null significa que no hay arco
    Float[][] matriz;
    //dirigido o no
    boolean dirigido;

    public GrafoMatriz(int n, int max, boolean d) {
        maxVertices = max;
        numVertices = n;
        matriz = new Float[maxVertices][maxVertices];
        dirigido = d;
    }

    public void agregarVertice() {
        if (numVertices == maxVertices) {
            System.out.println("No es posible agregar vertice!!!");
            return;
        }
        //Ingrementar el numero de vertices
        numVertices++;
    }

    public int numeroVertices() {
        //devuelde el numero de vertices del grafo
        return numVertices;
    }

    public void agregarArco(int i, int j) {
        //Por defecto, el arco es añadido con peso cero
        agregarArco(i, j, 0);
    }

    public void agregarArco(int i, int j, float w) {
        matriz[i][j] = w;
        //si el grafo es no dirigido debemos agregar también el arco simetrico
        if (!dirigido) {
            matriz[j][i] = w;
        }
    }

    public void eliminarArco(int i, int j) {
        //Actualizar el valor a null
        matriz[i][j] = null;
        //Si es un grafo no dirijido, debemos actualizar el simetrico
        if (!dirigido) {
            matriz[j][i] = null;
        }
    }

    public void mostrarGrafo() {
        //visitar las filas
        for (int i = 0; i < numVertices; i++) {
            //Para cada fila, visitar todas la columnas
            for (int j = 0; j < numVertices; j++) {
                //Imprimir el elemento en la matriz[i,j] y un espacio
                System.out.print(matriz[i][j] + "\t");
            }
            //Nuev linea para una nueva fila
            System.out.println();
        }
        System.out.println();
    }
    
    //Solución a la pregunta 1 de la practica calificada 2
    public int numArcosSalida(int i) {
        //Los grafos no dirigidos no tienen arcos de salida
        if (!dirigido) {
            System.out.println("Es un grafo no dirigido!!!");
            return 0;
        }

        int arcosSalida = 0;
        //contar las columnas que tienen un arco de i
        for (int col = 0; col < numVertices; col++) {
            if (matriz[i][col] != null) {
                arcosSalida++;
            }
        }
        return arcosSalida;
    }
    public void mostrarAdyacencias(){
        for (int i = 0; i < matriz.length/2; i++) {
            System.out.println("vertice: "+i);
            for (int j = 0; j < matriz[i].length; j++) {
                if(matriz[i][j]!=null) System.out.println("["+i+" ; "+j+"]");
            }
        }
    }
    public void adyacenciaIesima(int i){
        System.out.println("vertice solicitado: "+i);
        for (int j = 0; j < matriz[i].length; j++) {
            if(matriz[i][j]!=null) System.out.println("["+i+" ; "+j+"]");
        }
    }
    public boolean existeAdyacencia(int i, int j){
        if(matriz[i][j]!=null) return true;
        else return false;
    }
}
