/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tda.grafo.matriz;
public class Pregunta2 {
    public static void main(String[] args) {
        GrafoMatriz g=new GrafoMatriz(0, 10, true);
        g.agregarVertice(); //vertice 0
        g.agregarVertice(); //vertice 1
        g.agregarVertice(); //vertice 2
        g.agregarVertice(); //vertice 3
        g.agregarVertice(); //vertice 4
        g.agregarVertice(); //vertice 5
        g.agregarArco(0, 1);
        g.agregarArco(0, 2);
        g.agregarArco(1, 3);
        g.agregarArco(1, 4);
        g.agregarArco(2, 3);
        g.agregarArco(3, 1);
        g.agregarArco(4, 0);
        g.mostrarGrafo();
        System.out.println("inciso a");
        //muestra todas las adyacencias existentes en el grafo
        g.mostrarAdyacencias();
        System.out.println("inciso b");
        //devuelve las adyacencias del vertice solicitado
        g.adyacenciaIesima(0);
        System.out.println("inciso c");
        //devuelve verdadero si eiste adyacencia entre los vertices solicitados
        System.out.println("existe adyacencia? "+g.existeAdyacencia(0, 1));
    }
}
