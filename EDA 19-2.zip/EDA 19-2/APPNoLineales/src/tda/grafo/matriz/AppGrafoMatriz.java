package tda.grafo.matriz;

public class AppGrafoMatriz {

    public static void main(String args[]) {
        GrafoMatriz grafo = new GrafoMatriz(0, 8, true);
        grafo.agregarVertice(); // vertice 0
        grafo.agregarVertice(); // vertice 1
        grafo.agregarVertice(); // vertice 2
        
        grafo.agregarArco(0, 1);
        grafo.agregarArco(0, 2);
        grafo.agregarArco(2, 1);
        System.out.println();
        grafo.mostrarGrafo();
        System.out.println("Numero de arcos de salida del vertice: ["+0+"]: "+grafo.numArcosSalida(0));
    }

}
