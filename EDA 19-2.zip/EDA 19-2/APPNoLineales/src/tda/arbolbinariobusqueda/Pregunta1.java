/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tda.arbolbinariobusqueda;
public class Pregunta1 {
    public static void main(String[] args) {
        ArbolBB arbol=new ArbolBB();
        arbol.agregar(2);
        arbol.agregar(5);
        arbol.agregar(8);
        arbol.agregar(12);
        arbol.agregar(11);
        arbol.agregar(9);
        arbol.agregar(22);
        System.out.println("devuelve las relaciones genealogicas del arbol");
        arbol.devolverArbol();
    }
}
