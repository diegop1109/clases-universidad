package tda.arbolbinariobusqueda;

public class AppArbolBB {

    public static void main(String[] args) {

        ArbolBB arbol1 = new ArbolBB();
        arbol1.agregar(7);
        arbol1.agregar(5);
        arbol1.agregar(22);
        arbol1.agregar(11);
        arbol1.agregar(27);
        arbol1.agregar(6);
        arbol1.agregar(13);
        arbol1.agregar(3);
        System.out.println();
        arbol1.preOrden();
        System.out.println();
        int x = arbol1.sumaDeracha();
        System.out.println(x);
        int y = arbol1.sumaNodosHoja();
        System.out.println(y);

        
    }

}
