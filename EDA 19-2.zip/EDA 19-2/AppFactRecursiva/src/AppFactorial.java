/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B3106
 */
public class AppFactorial {
    public static void main(String[] args) {
        System.out.println("factorial Iterativo: "+factorialIterativo(5));
        System.out.println("factorial Recursivo: "+factorialRecursivo(5));
        System.out.println("potencia Iterativa: "+potenciaIterativa(3, 2));
        System.out.println("potencia Recursiva: "+potenciaRecursiva(3, 2));
        System.out.println("fibonazi recursivo: "+fibonaziRecursivo(5));
        System.out.println("hanoi:");
        hanoiRecursiva(3, 1, 2, 3);
        int d=12300;
        System.out.println("numero de digitos de "+d+" son: "+numDigitos(d));
    }
    //solucion iterativa del factorial
    public static double factorialIterativo(double n){
        if(n==0) return 1;
        else{
            double r=1;
            for (double i = n; i >=1; i--) {
                r=r*i;
            }
            return r;
        }
    }
    //solucion recursiva del factorial
    public static double factorialRecursivo(double n){
        //caso base - uno o más
        if(n==0) return 1;
        else{ //casos recurrentes - se llama a sí mismo
            return n*factorialRecursivo(n-1);
        }
    }
    //solucion iterativa de potencia
    public static double potenciaIterativa(double base, double exponente){
        if(exponente==0) return 1;
        else{
            double s=1;
            for (int i = 1; i <= exponente; i++) {
                s*=base; //s=s*base;
            }
            return s;
        }
    }
    //solucion recursiva de potencia
    public static double potenciaRecursiva(double base, double exponente){
        if(exponente==0) return 1;
        else{
            return base*potenciaRecursiva(base, exponente-1);
        }
    }
    //solucion fibonacci recursivo
    public static double fibonaziRecursivo(double n){
        //casos base - 0 ó 1
        if(n==0) return 0;
        if(n==1) return 1;
        else{ //caso recurrente
            return fibonaziRecursivo(n-1)+fibonaziRecursivo(n-2);
        }
    }
    //solucion a "la torre de hanoi" de forma recursiva
    public static void hanoiRecursiva(int discos, int origen, int auxiliar, int destino){
        //caso base
        if(discos==1) System.out.println("mover disco de "+origen+" a "+destino);
        else{//caso recurrente
            hanoiRecursiva(discos-1,origen, destino, auxiliar);
            System.out.println("mover disco de "+origen+" a "+destino);
            hanoiRecursiva(discos-1, auxiliar, origen, destino);
        }
    }
    //solucion recursiva para calcular el numero de digitos de un numero
    public static int numDigitos(int n){
        if(n<10) return 1;
        else{
            return 1+numDigitos(n/10);
        }
    }
    
}