/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Guia7;
public class listaRecursiva {
    public static void main(String[] args) {
        Lista lista=new Lista();
        lista.insertar("hola", 1);
        lista.insertar("adios", 2);
        lista.insertar("sayonara", 3);
        lista.insertar("wilkomen", 4);
        lista.agregar("bye");
        for (int i = 1; i <=lista.longitud(); i++) {
            System.out.print(lista.iesimo(i)+",\t");
        }System.out.println("");
        System.out.println("existe el elemento wilkomen? "+lista.existe("wilkomen"));
        lista.ordenInverso();
        //////////////ejer14///////////////
        Lista l=new Lista();
        l.insertar(12, 1);
        l.insertar(5, 2);
        l.insertar(8, 3);
        l.insertar(20, 4);
        System.out.println("que hace el algoritmo del ejer14? devuelve: "+l.ejer14(10, 0));
        //ni perra idea de como implementarla pero parece que funciona de forma que cuenta los numeros menores al valor dado
        
    }
}
