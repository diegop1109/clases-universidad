/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Guia7;
public class Lista {
    private Object elemento;
    private Lista sublista;
    /////////////
    public Lista(){
        elemento=null;
        sublista=null;
    }
    public Lista(Object nuevo, Lista lista){
        elemento=nuevo;
        sublista=lista;
    }
    public Object getElemento() {
        return elemento;
    }
    public void setElemento(Object elemento) {
        this.elemento = elemento;
    }
    public Lista getSublista() {
        return sublista;
    }
    public void setSublista(Lista sublista) {
        this.sublista = sublista;
    }
    //////////////////////
    public boolean esVacia(){
        if(elemento==null && sublista==null) return true;
        else return false;
    }
    public int longitud(){
        if(esVacia()) return 0;
        else{
            return 1+sublista.longitud();
        }
    }
    public Object iesimo(int posicion){
        if(posicion==1) return elemento;
        else{
            return sublista.iesimo(posicion-1);
        }
    }
    public void insertar(Object nuevoElem, int posicion){
        if(posicion==1){
            sublista=new Lista(elemento, sublista);
            elemento=nuevoElem;
        }else{
            sublista.insertar(nuevoElem, posicion-1);
        }
    }
    public int ubicar(Object elem){
        if(elemento.equals(elem)) return 1;
        else{
            return 1+sublista.ubicar(elem);
        }
    }
    public void eliminar(int posicion){
        if(posicion==1){
            elemento=sublista.getElemento();
            sublista=sublista.getSublista();
        }else{
            sublista.eliminar(posicion-1);
        }
    }
    //aun no o pruebo (facil es una cagada)
    //esta cagada ya fue probada y si funciona
    //agregar: agrega un elemento al final de la lista
    public void agregar(Object nuevoElem){
        if(esVacia()){
            sublista=new Lista(elemento, sublista);
            elemento=nuevoElem;
        }else{
            sublista.agregar(nuevoElem);
        }
    }
    //existe: verifica si un elemento especificado de la lista existe en esta o no
    public boolean existe(Object nuevoElem){
        if(esVacia()) return false;
        else{
            if(elemento.equals(nuevoElem)) return true;
            else{
                return sublista.existe(nuevoElem);
            }
        }
    }
    //ordenInverso: imprime los elementos de la lista en orden invertido
    public void ordenInverso(){
        if(sublista.esVacia()) System.out.println(elemento);
        else{
            sublista.ordenInverso();
        }
    }
    public int ejer14(int x, int n){
        if(esVacia()) return n=0;
        else{
            if((int)elemento<x) return n=n+1;
            sublista.ejer14(x, n);
            return n;
        }
    }
}
