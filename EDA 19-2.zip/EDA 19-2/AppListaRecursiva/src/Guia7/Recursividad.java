/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Guia7;
public class Recursividad {
    //ejer1: (1/1)+(1/2)+(1/3)+...+(1/n)
    public static float ejer1(float n){ //no sale si el metodo es "int" o "double", pero si con "float"
        //caso base
        if(n==0) return 0;
        else{ //caso recurrente
            return (1/n)+ejer1(n-1);
        }
    }
    //ejer2: potencia de un numero elevado a la "n"
    public static float ejer2(int x, int n){
        //caso base
        if(n==0) return 1;
        else{ //caso recurrente
            return x*ejer2(x, n-1);
        }
    }
    //ejer4: nos dan un algoritmo que no sabemos que hace
    public static int ejer4(int x, int y){ //funcion F: halla la potencia de x elevado a la y
        int g=0;
        if(y==0) g=1;
        else{
            g=x*ejer4(x, y-1);
        }
        return g;
    }
    //ejer5: devolvera la sumatoria de los elementos de un arreglo
    public static int ejer5(int[] a, int n){
        if(n==0) return a[0];
        else{
            return a[n]+ejer5(a, n-1);
        }
    }
    public static int ejer6(int[] a, int n, int x){
        if(n==-1) return 0;
        else{
            if(a[n]<=x) return 1+ejer6(a,n-1,x);
            else{
                return ejer6(a,n-1,x);
            }
        }
    } 
    public static boolean ejer7(int[] a, int n, int dato){
        if(n==-1) return false;
        else{
            if(a[n]==dato) return true;
            else{
                return ejer7(a,n-1,dato);
            }
        }
    }
    public static int ejer8(int[] a,int primero, int ultimo){ //el ejercicio 8 y el 13 son lo mismo
        if(primero==ultimo) return a[primero];
        else{
            int x=ejer8(a, primero, (primero+ultimo)/2);
            int y=ejer8(a, ((primero+ultimo)/2)+1, ultimo);
            if(x>y) return x;
            else return y;
        }
    }
    public static boolean ejer9(int[] a, int n){
        if(n==-1) return true;
        else{
            if(a[n]<0) return false;
            else{
                return ejer9(a,n-1);
            }
        }
    }
    public static void main(String[] args) {
        //ejer1
        float n=5;
        System.out.println("sumatoria fraccionaria de n: "+ejer1(n));
        //ejer2
        int potencia=3; int real=7;
        System.out.println("potencia de "+real+" elevado a la "+potencia+": "+ejer2(real, potencia));
        //ejer4
        int x=2; int y=3;
        System.out.println("funcion f(ejer4) está resultando: "+ejer4(x, y));
        //ejer5
        int[] arreglo={2,4,5,8,1};
        int tam=arreglo.length-1;
        System.out.println("sumatoria de los elementos de un arreglo: "+ejer5(arreglo, tam));
        //ejer6
        int[] arreglo2={3,5,7,8,1,9};
        int tam2=arreglo2.length-1;
        int num=0;
        System.out.println("en un arreglo de n elementos, devolvemos la cantidad de aquellos menores o iguales a x: "+ejer6(arreglo2,tam2,num));
        //ejer7
        int[] arreglo3={1,6,3,45,8,7,0};
        int pos=arreglo3.length-1;
        int dato=65;
        System.out.println("¿se ha encontrado el dato en el arreglo?: "+ejer7(arreglo3,pos,dato));
        //ejer8
        int[] arreglo4={2,5,67,11,0,7};
        int ultimo=arreglo4.length-1;
        int primero=0;
        System.out.println("el mayor elemento del arreglo es: "+ejer8(arreglo4,primero,ultimo));
        //ejer9
        int[] arreglo5={3,667,-1,5,2};
        int ultimo5=arreglo5.length-1;
        System.out.println("todos los elementos del arreglo son positivos?: "+ejer9(arreglo5, ultimo5));
        
    }
}
