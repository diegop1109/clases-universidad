/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author R4604
 */
public class AppLista {
    public static void main(String[] args) {
        Lista l1=new Lista();
        l1.insertar("Juan", 1);
        l1.insertar("Ana", 2);
        l1.insertar("Pedro", 3);
        System.out.println("ana: "+l1.ubicar("Ana"));
        for (int i = 1; i <= l1.longitud(); i++) {
            System.out.println("elem["+i+"] : "+l1.iesimo(i));
        }System.out.println("");
        //insertar al inicio
        l1.insertar("Patty", 1);
        l1.insertar("carlos", 3);
        System.out.println("buscar a carlos: "+l1.ubicar("carlos"));
        l1.eliminar(3);
        System.out.println("buscar a sonya "+l1.ubicar("sonya"));
        for (int i = 1; i < l1.longitud(); i++) {
            System.out.println("elem["+i+"] : "+l1.iesimo(i));
        }
    }
}
