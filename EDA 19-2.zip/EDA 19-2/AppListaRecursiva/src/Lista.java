/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author R4604
 */
public class Lista {
    //datos del TDALista
    private Object elemento;
    private Lista subLista;
    //operaciones de la TDALista
    public Lista(){
        elemento=null;
        subLista=null;
    }
    public Lista(Object nuevoElemento, Lista lista){
        elemento=nuevoElemento;
        subLista=lista;
    }
    public Object getElemento() {
        return elemento;
    }
    public void setElemento(Object elemento) {
        this.elemento = elemento;
    }
    public Lista getSubLista() {
        return subLista;
    }
    public void setSubLista(Lista subLista) {
        this.subLista = subLista;
    }
    public boolean esVacia(){
        if(elemento==null && subLista==null) return true;
        else return false;
    }
    //devuelve la cantidad de elementos de la lista
    public int longitud(){
        //caso base
        if(esVacia()) return 0;
        else{//caso recurrente
            return 1+subLista.longitud();
        }
    }
    //iesimo: devuelve el iesimo elemento de la lista, dada una posicion
    //precondicion: 1 <= posicion <= longitudLista
    public Object iesimo(int posicion){
        //caso base
        if(posicion==1) return elemento;
        else{//caso recurrente
            return subLista.iesimo(posicion-1);
        }
    }
    //insertar: añade un elemento a la lista en una posicion determinada
    //precondicion: 1 <= posicion <= longitudLista+1
    public void insertar(Object nuevoElem, int posicion){
        //caso base
        if(posicion==1){
            subLista=new Lista(elemento, subLista);
            elemento=nuevoElem;
        }else{//caso recurrente
            subLista.insertar(nuevoElem, posicion-1);
        }
    }
    //ubicacion: indica el objeto y devuelve la posicion de este
    public int ubicar(Object elem){
        //caso base 
        if(elemento.equals(elem)) return 1;
        else{ //caso recurrente
            return 1+subLista.ubicar(elem);
        }
    }
    //eliminar: 
    public void eliminar(int posicion){
        //caso base
        if(posicion==1){
            elemento=subLista.getElemento();
            subLista=subLista.getSubLista();
        }else{ //caso recurrente
            subLista.eliminar(posicion-1);
        }
    }
    //implementar:
    //agregar: agrega siempre a la ultima posicion
    //existe: verifica si un elemnto existe
    //limpiar: 
    //plantear recursividad con arreglos
}
