package appgrafos;
public class AppGrafos {
    public static void main(String[] args) {
//        double num=34.6767;   //tipo primitivo
//        System.out.println(num);
        Vertice v1=new Vertice("a"); //tipo de clase u objeto
        Vertice v2=new Vertice("b");
//        System.out.println(v1);
//        System.out.println(v2);
//        if(v1.equals(v2)) System.out.println("son iguales");
//        else System.out.println("son diferentes");
        Vertice v3=new Vertice("c");
        Vertice v4=new Vertice("d");
        
        //crear el grafo
        Grafo g=new Grafo();
        g.agregarVertice(v1);
        g.agregarVertice(v2);
        g.agregarVertice(v3);
        g.agregarVertice(v4);
        g.mostrarGrafo();
        //agregar los arcos
        g.agregarArco(v1, v2);
        g.agregarArco(v1, v3);
        g.agregarArco(v2, v4);
        g.agregarArco(v3, v4);
        System.out.println("grafo resultante:");
        g.mostrarGrafo();
        System.out.println("numero de vertices actualmente: "+g.numVertices());
        System.out.println("eliminar uno de los arcos:");
        g.eliminarArco(v2, v4);
        g.mostrarGrafo();
        System.out.println("verificar adyacencia entre dos vertices:");
        System.out.println("existe adyacencia entre los vertices? "+g.verticesAdyacentes(v1, v2));
    }
}
