package appgrafos;
public class Vertice {
    //atributos
    private String nombre;
    public Vertice() {
    }
    public Vertice(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    @Override
    public String toString() {
        return nombre;
    }
    @Override
    public boolean equals(Object obj){
        if(obj==null) return false; //si es nulo, entonces devuelvo falso
        else return nombre.equals(obj.toString()); //comparar nombres
    }
}
