package appgrafos;
public class Grafo {
    private Vertice aVertice; //atributo vertice
    private Lista listaAdyacencia;
    private Grafo subGrafo;
    public Grafo() {
        this.aVertice=null;
        this.listaAdyacencia=null;
        this.subGrafo=null;
    }
    public Grafo(Vertice aVertice, Lista listaAdyacencia, Grafo subGrafo) {
        this.aVertice = aVertice;
        this.listaAdyacencia = listaAdyacencia;
        this.subGrafo = subGrafo;
    }
    public Vertice getaVertice() {
        return aVertice;
    }
    public void setaVertice(Vertice aVertice) {
        this.aVertice = aVertice;
    }
    public Lista getListaAdyacencia() {
        return listaAdyacencia;
    }
    public void setListaAdyacencia(Lista listaAdyacencia) {
        this.listaAdyacencia = listaAdyacencia;
    }
    public Grafo getSubGrafo() {
        return subGrafo;
    }
    public void setSubGrafo(Grafo subGrafo) {
        this.subGrafo = subGrafo;
    }
    //operaciones
    public boolean estaVacio(){
        return aVertice==null;
    }
    public boolean existeVertice(Vertice pVertice){
        //caso base
        if(estaVacio() || pVertice==null) return false;
        else{ //caso recuurente: existe un grafo
            if(aVertice.equals(pVertice)) return true;
            else return this.subGrafo.existeVertice(pVertice);
        }
    }
    //agregar un vertice
    public void agregarVertice(Vertice pVertice){
        //el vertice nuevo no debe existir en el grafo y debe ser diferente de null
        if(pVertice!=null && !existeVertice(pVertice)){ //si esto se cumple, sera posible agregar un vertice
            if(estaVacio()){ //agregar el vertice cuando el grafo esta vacio (tiene elementos)
                this.aVertice=new Vertice(pVertice.getNombre());
                this.listaAdyacencia=new Lista();
                this.subGrafo=new Grafo();
            }else{ //el grafo tiene elementos
                //para el compareTo: si te devuelve 0, entonces son iguales. caso contrario son diferentes
                if(pVertice.getNombre().compareTo(aVertice.getNombre())<0){ //si no son iguales
                    //la etiqueta del nuevo vertice es menor a la etiqueta del primer vertice
                    Grafo gAux=new Grafo(aVertice,listaAdyacencia,subGrafo);
                    aVertice=new Vertice(pVertice.getNombre());
                    subGrafo=gAux;
                }else{
                    subGrafo.agregarVertice(pVertice);
                }
            }
        }
    }
    //agregar un arco al grafo
    public void agregarArco(Vertice verticeOrigen, Vertice verticeDestino){
        //es necesario que el origen y el destino esten dentro del grafo
        if(existeVertice(verticeOrigen) && existeVertice(verticeDestino)){
            agregar(verticeOrigen, verticeDestino);
        }else System.out.println("no es posible agregar");
    }
    public void agregar(Vertice verticeOrigen, Vertice verticeDestino){
        //primero debo ubicarme en el vertice de origen
        if(existeVertice(verticeOrigen)){
            if(aVertice.equals(verticeOrigen)){
                //verificar si el vertice destino esta en la lista
                if(listaAdyacencia.ubicacion(verticeDestino.getNombre())==0){
                    //el vertice destino no existe en la lista. Entonces lo insertamos
                    listaAdyacencia.insertar(verticeDestino, listaAdyacencia.longitud()+1);
                }
            }//el primer vertice no es el de origen
            else{ //seguir buscando el verticeOrigen en el subgrafo
                //vertice destino en su lista de Adyacencia
                if(subGrafo!=null){
                    subGrafo.agregar(verticeOrigen, verticeDestino);
                }
            }
        }
    }
    public int numVertices(){
        if(estaVacio()) return 0;
        else{
            return 1+subGrafo.numVertices();
        }
    }
    public void mostrarGrafo(){
        if(!estaVacio()){
            System.out.print("Vertice: "+aVertice);
            System.out.print(" arcos a: [");
            //mostrar los vertices de la lista de adyacencia
            for (int i=1; i<=listaAdyacencia.longitud(); i++) {
                System.out.print(listaAdyacencia.iesimo(i)+"\t");
            }System.out.print("]");
            System.out.println();
            subGrafo.mostrarGrafo();
        }
    }
    public void eliminarArco(Vertice origen, Vertice destino){
        if (existeVertice(origen) && existeVertice(destino)) {
            eliminar(origen, destino);
        } else {
            System.out.println("Error...No se elimino arco");
        }
    }
    public void eliminar(Vertice verticeOrigen, Vertice verticeDestino) {
        if (existeVertice(verticeOrigen)) {
            if (this.aVertice.equals(verticeOrigen)) {
                int pos = this.listaAdyacencia.ubicacion(verticeDestino.getNombre());
                if ( pos > 0) {
                    this.listaAdyacencia.eliminar(pos);
                }
            } else {
                if (this.subGrafo != null) {
                    this.subGrafo.eliminar(verticeOrigen, verticeDestino);
                }
            }
        }
    }
    public void eliminarVertice(Vertice pVertice) {
        if (existeVertice(pVertice)) {
            Grafo gAux = this.subGrafo;
            Vertice vAux = this.aVertice;
            while (gAux!=null){
                eliminar(vAux, pVertice);
                vAux = gAux.aVertice;
                gAux = gAux.subGrafo;                
            }
            if (this.aVertice.equals(pVertice)) {
                this.aVertice = this.subGrafo.aVertice;
                this.listaAdyacencia = this.subGrafo.listaAdyacencia;
                this.subGrafo = this.subGrafo.getSubGrafo();
            } else {
                this.subGrafo.eliminarVertice(aVertice);
            }
        }
    }
    public boolean verticesAdyacentes(Vertice origen, Vertice destino){
        if(!estaVacio()){
            if(aVertice.equals(origen)){
                for (int i=1; i<=listaAdyacencia.longitud(); i++) {
                    if(listaAdyacencia.iesimo(i).equals(destino)) return true;
                }
            }else{
                return subGrafo.verticesAdyacentes(origen, destino);
            }
        } return false;
    }
}
