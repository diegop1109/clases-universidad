package tda.listas;
public class Lista {
    private Nodo primerNodo;

    public Lista() {
        this.primerNodo = new Nodo();
    }
    public Lista(Nodo primerNodo){
        this.primerNodo = primerNodo;
    }
    public Lista(Object elemento, Nodo sgteNodo) {
        this.primerNodo.setElemento(elemento);
        this.primerNodo.setSgteNodo(sgteNodo);
    }

    public Nodo getPrimerNodo() {
        return primerNodo;
    }

    public void setPrimerNodo(Nodo primerNodo) {
        this.primerNodo = primerNodo;
    }
    
public boolean esVacia(){
    if (primerNodo.getElemento()== null &&
            primerNodo.getSgteNodo()==null)
        return true;
    else
        return false;
}  
/*
* Insertar 
*/
public void insertar(Object elemento, int posicion){
    // Inserción al inicio del lista
    if (posicion == 1){
        //Si la lista esta Vacia
        if (esVacia()){
            primerNodo.setElemento(elemento);
        }else{ // La Lista no es Vacia
            Object actualElemento = primerNodo.getElemento();
            Nodo actualSgteNodo = primerNodo.getSgteNodo();
            Nodo nodoAux = new Nodo(actualElemento, actualSgteNodo);
            primerNodo.setSgteNodo(nodoAux);
            primerNodo.setElemento(elemento);
        }
        
    }else{ // Posicion > 1
        // Buscar la posicion a insertar
        Nodo nodoAux = primerNodo;
        // Ubicar la posicion anterior en la quedeseamos insertar 
        int i=1;
        while (i<posicion-1){
            // Avanzar al siguiente nodo
            nodoAux = nodoAux.getSgteNodo();
            i++;
        }
        // Crear un nuevo nodo a insertar
        Nodo nuevoNodo = new Nodo(elemento,nodoAux.getSgteNodo());
        nodoAux.setSgteNodo(nuevoNodo);
    }
}

/*
// Iesimo Recupera el i-ésimo elemento de la lista
* Precondición: 1<=posicion<=longitud
*/
public Object iesimo(int posicion){
    Nodo nodoAux = primerNodo;
    int i=1;
    while (i<posicion){
        nodoAux = nodoAux.getSgteNodo();
        i++;
    }
    return nodoAux.getElemento();
}
/*
* Longitud: Determina la longitud de la lista (Cantidad de elemento en la lista)
*/
public int longitud(){
    if (esVacia()){
        return 0;
    }else{
        int i=1;
        Nodo nodoAux = primerNodo;
        while (nodoAux.getSgteNodo()!=null){
            nodoAux = nodoAux.getSgteNodo();
            i++;
        }
        return i;
    }
}
/*
* Ubicación: obtiene la ubicacion o posicon de un elemento en la lista
*/    
public int ubicacion(Object elemento){
    if (esVacia()){
        return 0;
    }else{
        Nodo nodoAux = primerNodo;
        int i = 1;
        while (!(nodoAux.getElemento().equals(elemento))
                && i<=longitud()){
            i++;
            // En caso que el SgteNodo sea vacio, es el final de la lñista
            if (nodoAux.getSgteNodo()==null){
                return 0;
            }else{
                nodoAux = nodoAux.getSgteNodo();
            }
        }
        return i;
    }
}
/*
* Eliminar un elemento de la Lista
* 1<=posicion<=tamaño de la lista
*/
public void eliminar(int posicion){
    if (posicion>=1 && posicion<=longitud()){
        // Buscar la posicion del elemento a eliminar
        Nodo nodoAux = primerNodo;
        int i=1;
        while (i<posicion-1){
            nodoAux = nodoAux.getSgteNodo();
            i++;
        }
        // Eliminar el elemento
        Nodo nodoAux2 = nodoAux.getSgteNodo();
        nodoAux.setSgteNodo(nodoAux2.getSgteNodo());
    }
}
    
    
}
