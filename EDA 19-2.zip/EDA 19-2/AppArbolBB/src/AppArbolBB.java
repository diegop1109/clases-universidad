public class AppArbolBB {
    public static void main(String[] args) {
        //crear arbolBB
        ArbolBB arbol=new ArbolBB();
        arbol.agregar(36);
        arbol.agregar(81);
        arbol.agregar(25);
        arbol.agregar(35);
        arbol.agregar(33);
        arbol.agregar(74);
        arbol.agregar(10);
        arbol.agregar(90);
        arbol.agregar(9);
        System.out.println("total de nodos del arbol: "+arbol.numNodos());
        arbol.eliminar(35);
        System.out.println("total de nodos del arbol: "+arbol.numNodos());
        //recorrido del arbol en preorden
        System.out.println("recorrido del arbol en preOrden: ");
        arbol.preOrden(); System.out.println("");
        System.out.println("minimo: "+arbol.minimo());
        System.out.println("maximo: "+arbol.maximo());
        System.out.println("recorrido del arbol en inOrder: ");
        arbol.inOrder(); System.out.println("");
        System.out.println("cuantos nodos tienen un solo hijo? "+arbol.unSoloHijo());
    }
}
