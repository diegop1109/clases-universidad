public class ArbolBB { //un arbol es un TDA
    //atributos
    private Object raiz;
    private ArbolBB subArbolIzq;
    private ArbolBB subArbolDer;
    private int n;
    //operaciones
    public ArbolBB() {
        this.raiz=null;
        this.subArbolDer=null;
        this.subArbolIzq=null;
    }
    public ArbolBB(Object raiz, ArbolBB subArbolIzq, ArbolBB subArbolDer) {
        this.raiz = raiz;
        this.subArbolIzq = subArbolIzq;
        this.subArbolDer = subArbolDer;
    }
    public Object getRaiz() {
        return raiz;
    }
    public void setRaiz(Object raiz) {
        this.raiz = raiz;
    }
    public ArbolBB getSubArbolIzq() {
        return subArbolIzq;
    }
    public void setSubArbolIzq(ArbolBB subArbolIzq) {
        this.subArbolIzq = subArbolIzq;
    }
    public ArbolBB getSubArbolDer() {
        return subArbolDer;
    }
    public void setSubArbolDer(ArbolBB subArbolDer) {
        this.subArbolDer = subArbolDer;
    }
    ////////////////////////////////////////////////////////////////////////////
    public boolean estaVacia(){ //verifica si esta vacio
        return raiz==null;
    }
    public void agregar(Object elemento){
        n++;
        if(estaVacia()) raiz=elemento;
        else{ //el arbol tiene elementos
            //primero verificamos si el elmento debe ir a la izquierda
            if(elemento.toString().compareTo(raiz.toString())<0){ //sub arbol izquierdo
                if(subArbolIzq==null) subArbolIzq=new ArbolBB(elemento, null, null);
                else subArbolIzq.agregar(elemento);
            }else{
                if(elemento.toString().compareTo(raiz.toString())>0){
                    if(subArbolDer==null) subArbolDer=new ArbolBB(elemento, null, null);
                    else subArbolDer.agregar(elemento);
                }
            }
        }
    }
    public void preOrden(){
        if(!estaVacia()){
            //primero: procesar la raiz
            System.out.print(raiz+"\t");
            //recorrido en preOrden del subArbolIzquierdo
            if(subArbolIzq!=null) subArbolIzq.preOrden();
            //recorrido en preOrden del subArbolDerecho
            if(subArbolDer!=null) subArbolDer.preOrden();
        }
    }
    public Object minimo(){
        if(!estaVacia()){
            if(subArbolIzq==null) return raiz;
            else{
                return subArbolIzq.minimo();
            }
        }else return 0;
    }
    public Object maximo(){
        if(!estaVacia()){
            if(subArbolDer==null) return raiz;
            else{
                return subArbolDer.maximo();
            }
        }else return 0;
    }
    public void eliminar(Object elemento) {
        if (estaVacia()) {
            System.out.println("No existe el elemento en el arbol");
        } else {
            n--;
            // Verificar si el elemento a eliminfar es la raiz
            if (elemento.toString().equals(raiz.toString())) {
                // Si la raiz es una hoja o no tiene subarbol izq. y der
                if (subArbolIzq == null && subArbolDer == null) {
                    raiz = null;
                } else { // Tiene subarbol izq, der o ambos
                    // Verificar si solo tiene subarbol izq
                    if (subArbolDer == null) {
                        raiz = subArbolIzq.getRaiz();
                        subArbolDer = subArbolIzq.getSubArbolDer();
                        subArbolIzq = subArbolIzq.getSubArbolIzq();
                    } else { //Verificar si solo tiene subarbol derecho
                        if (subArbolIzq == null) {
                            raiz = subArbolDer.getRaiz();
                            subArbolIzq = subArbolDer.getSubArbolIzq();
                            subArbolDer = subArbolDer.getSubArbolDer();
                        } else { // Tiene ambos hijos
                            raiz = subArbolDer.minimo();
                            subArbolDer.eliminar(subArbolDer.minimo());
                        }
                    }
                }
            } else { // Se desea eliminar dentro de los subarboles
                // Verificar si queremos eliminar en el subarbolizq
                if (elemento.toString().compareTo(raiz.toString()) < 0) {
                    if (subArbolIzq != null) {
                        subArbolIzq.eliminar(elemento);
                    }

                } else { // Eliminar en el subarbol derecho
                    if (subArbolDer != null) {
                        subArbolDer.eliminar(elemento);
                    }
                }
            }
            // Verificar si los hijos son hojas vacias 
            if ((subArbolIzq != null) && subArbolIzq.estaVacia()) {
                subArbolIzq = null;
            }
            if ((subArbolDer != null) && subArbolDer.estaVacia()) {
                subArbolDer = null;
            }
        }
    }
    public void inOrder(){
        if(!estaVacia()){
            if(subArbolIzq!=null) subArbolIzq.inOrder();
            System.out.print(raiz+"\t");
            if(subArbolDer!=null) subArbolDer.inOrder();
        }
    }
    public void posOrden(){
        if(!estaVacia()){
            if(subArbolIzq!=null) subArbolIzq.posOrden();
            if(subArbolDer!=null) subArbolDer.posOrden();
            System.out.print(raiz+"\t");
        }
    }
    public int numNodos(){
        return n;
    }
    public int unSoloHijo(){
        if(subArbolDer==null && subArbolIzq==null) return 0;
        else{
            
        }
    }
}
