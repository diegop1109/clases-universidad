/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo_clase_abstracta;

/**
 *
 * @author W3217
 */
public class Socio extends Persona{
    int codigo_socio;
    int Antiguedad;
    int consumo;

    public Socio(int codigo_socio, String Nombre, int DNI,int Antiguedad,int consumo) {
        super(Nombre, DNI);
        this.codigo_socio = codigo_socio;
        this.Antiguedad=Antiguedad;
        this.consumo=consumo;
    }
    @Override
    public float RealizarPago() {
        float porcentaje;
        if (Antiguedad<=5){
            porcentaje=40;
        }else{
            if (Antiguedad>5 && Antiguedad<=10){
                porcentaje=30;
            }else{
                porcentaje=20;
            }
        }
        return porcentaje;
    }
    public float indicarConsumo(){
        return consumo;
    }
}
