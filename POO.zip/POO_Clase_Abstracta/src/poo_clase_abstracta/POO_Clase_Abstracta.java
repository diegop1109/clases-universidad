/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo_clase_abstracta;

/**
 *
 * @author W3217
 */
public class POO_Clase_Abstracta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Socio s1=new Socio(4023, "Carlos Perez", 70213091, 8, 700);
        float descuento=s1.RealizarPago();
        float consumo=s1.indicarConsumo();
        float pago_fina_Socio=consumo-descuento*consumo;
        
        No_Socio ns1=new No_Socio("Andres Diaz", 48247212, 3, 600);
        float pago_entrada=ns1.RealizarPago();
        float consumo_no_socio=ns1.consumo;
        float pago_final_ns1=pago_entrada+consumo_no_socio;
        
        System.out.println("Pago Total "+pago_final_ns1);
    }
    
}
