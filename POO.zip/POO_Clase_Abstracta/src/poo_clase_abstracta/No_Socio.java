/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo_clase_abstracta;

/**
 *
 * @author W3217
 */
public class No_Socio extends Persona{

    int num_veces_entra;
    int consumo;
    
    public No_Socio(String Nombre, int DNI,int num_veces_entra,int consumo) {
        super(Nombre, DNI);
        this.num_veces_entra=num_veces_entra;
        this.consumo=consumo;
    }
    
    @Override
    public float RealizarPago() {
        float pago;
        if (num_veces_entra==1){
            pago=250;
        }else{
            if(num_veces_entra>=2 && num_veces_entra<=6){
                pago=150;
            }else{
                pago=100;
            }
        }
        return pago;
    }
}
