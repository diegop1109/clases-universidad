/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo_clase_abstracta;

/**
 *
 * @author W3217
 */
public abstract class Persona {
    
    String Nombre;
    int DNI;

    public Persona(String Nombre, int DNI) {
        this.Nombre = Nombre;
        this.DNI = DNI;
    }
    
    public abstract float RealizarPago();
}
