/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo_leer_archivo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author w3218
 */
public class POO_LEER_ARCHIVO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        String cadena;
        
        //En caso el archivo no exista
        FileReader f=null;
        try {
            f=new FileReader("D:/DATA.txt");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(POO_LEER_ARCHIVO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        BufferedReader b=new BufferedReader(f);
        
        
        //En caso el archivo exista, pero este vacio
        try{
            while((cadena=b.readLine())!=null){
            System.out.println(cadena);
            }
        }catch(IOException ex){
                Logger.getLogger(POO_LEER_ARCHIVO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        //en caso el archivo no se pueda cerrar
        try{
            b.close();
        }catch(IOException ex){
            Logger.getLogger(POO_LEER_ARCHIVO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
